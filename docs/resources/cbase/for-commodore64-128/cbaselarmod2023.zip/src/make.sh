#!/bin/bash

#
# make.sh - compile and install C*BASE 3.1 LAR mod Files
#
# Written by
#  Larry / ROLE <larrycool@web.de>
#
# This file is part of C*BASE 3.1 Larry Mod
# See README for copyright notice.
#
#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2 of the License, or
#  (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA
#  02111-1307  USA.
#


current_dir=`pwd`
SRC="/home/larry/C64/bbs/larrymod/src/"
DIST="../dist/"
BLITZ="./tools/blitz"
EXO="./tools/exomizer"
BPP="./tools/bpp"
# VICE installation needed
PETCAT=petcat
C1541=c1541
#ctype=austro
ctype=blitz

if test x"$current_dir" != "/home/larry/C64/bbs/larrymod/src/"; then
    cd $SRC
fi

function makeblitzmodule() {
#compile without Runtime Code
        local blitzfile=${outfile}
        local outcomp=c-${blitzfile}
        rm -f -r $outcomp && rm -f -r $outcomp.xref && rm -f -r
        ${BLITZ} -c $ctype -p -o $outcomp $blitzfile
        #remove Runtime Code from compiled File and write into 'real' target. P-Code start $1F93 - $0801 + $2 = $1794 = 6036
        #(printf '\x93\x1f'; dd bs=1 if=$outtmp skip=6036) > $outcomp
        #rm -f -r $outtmp
        #mv $outtmp.xref $outcomp.xref
        outfile=$outcomp
}


function makeblitz() {
#compile with Runtime Code
        local blitzfile=${outfile}
        outcomp=c-${blitzfile}
#        echo "Outcomp:"$outcomp
        rm -f -r $outcomp && rm -f -r $outcomp.xref
        ${BLITZ} -c $ctype -o $outcomp $blitzfile
        outfile=$outcomp
}


function bpp2bas() {
        local bppfile=${infile}
        local outbas=${infile%bpp}bas
        rm -f -r $outbas
        ${BPP} < ${bppfile} | sed 's/£/\\/g;s/←/_/g' > ${outbas}
}

function translate() {
        local basfile=${infile%bpp}
        basfile=${basfile%bas}bas
        local outprg=${basfile%bas}prg
        #rm -f -r $outbas && rm -f -r $outprg && rm -f -r $outprg.xref
        petcat -w2 -c -o ${outprg} -- ${basfile}
        outfile=${outprg}
}

function crunch() {
        local exofile=${outfile}
#        echo "exofile:"$exofile
        crunchfile=${outfile%.prg}.exo.prg
#        echo "crunchfile:"$crunchfile
        rm -f -r $crunchfile
        ${EXO} sfx basic $exofile -o $crunchfile
        outfile=$crunchfile
}

function floppy() {
        local diskfile=${outfile}
        echo "Diskfile:"$diskfile
        local outimg=${outfile##*c-}
        local outcru=${crunchfile##*c-}
#        local outxref=${diskfile##*c-}
        local outxref=${diskfile%%.*}.prg.xref

        echo "XREF:"$outxref
        rm -f -r ${outimg%%.*}.d64
        #echo "Compiled InFile: "$infile
        #echo "Image name: "${outimg%.*}.d64
        c1541 -disable-libdebug-output -silent -format "cbase,01" d64 ${outimg%.*}.d64 -attach ${outimg%.*}.d64 -write ${diskfile} "c-"${outimg%.prg} -write ${outxref} "z/"${outxref##*c-}
#        if ${crunchfile} <>""; then
#            c1541 -write ${crunchfile} "c-"${outcru%.prg}
#        fi
}


while getopts ':bcedmpi:' OPTION ; do
    case "${OPTION}" in

        b)      echo "Translateing BPP to BAS File"
                bpp2bas
                ;;  
        p)      echo "PETCAT BAS to C64 BASIC PRG File"
                translate
                ;;
            
        c)      echo "Compiling BASIC PRG File with Runtime Code"
                makeblitz $outfile
                ;;
        m)      echo "Compiling BASIC PRG File as Module"
                makeblitzmodule $outfile
                ;;
        e)      echo "Crunching: "$outfile
                crunch $outfile
                ;;
        d)      echo "Writing File(s) to .d64"
                echo "Filename: "$outfile
                floppy
                ;;
#        o)      echo "Outfile: "$OPTARG
#                outfile=${OPTARG}
#                ;;
        i)      echo "Infile: "$OPTARG
                infile=${OPTARG}
                ;;
        *)      echo "Usage: ./make.sh -i inputfile [OPTION1]...[OPTION2]..."
                echo ""
                echo "Options:"
                echo "-b, Translateing BPP to BAS File"
                echo "-p, PETCAT BAS to C64 BASIC PRG File"
                echo "-c, Compile BASIC file with Runtime Code"
                echo "-m, Compile BASIC file without Runtime Code (as Blitz Module)"
                echo "-e, Crunch File with Exomizer"
                echo "-d, Write File(s) to Diskimage"
                echo ""
                echo "Should be used in order: -i Filename -b -p -c or -m [-e] [-i]"
    esac
done
shift $((OPTIND-1))

