#!/bin/bash

#
# make.sh - compile and install C*BASE 3.1 LAR mod Files
#
# Written by
#  Larry / ROLE <larrycool@web.de>
# SED Commands with the help of User drazil from Forum64.de
#
# This file is part of C*BASE 3.1 Larry Mod
# See README for copyright notice.
#
#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2 of the License, or
#  (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA
#  02111-1307  USA.
#


current_dir=`pwd`
SRC="/home/larry/C64/bbs/larrymod/src/"
DIST="/home/larry/C64/bbs/larrymod/dist/"
BLITZ="/home/larry/C64/linux/blitz"
EXO="/home/larry/C64/linux/exomizer"
BPP="/home/larry/C64/linux/bpp"
PETCAT=petcat
C1541=c1541
infile=larry-boot.bpp
#ctype=austro
ctype=blitz

if test x"$current_dir" != "/home/larry/C64/bbs/larrymod/src/"; then
    cd $SRC
fi

function makeblitzmodule() {
#compile without Runtime Code
        local blitzfile=${outfile}
        local outcomp=c-${blitzfile}
        rm -f -r $outcomp && rm -f -r $outcomp.xref && rm -f -r
        ${BLITZ} -c $ctype -p -o $outcomp $blitzfile
        #remove Runtime Code from compiled File and write into 'real' target. P-Code start $1F93 - $0801 + $2 = $1794 = 6036
        #(printf '\x93\x1f'; dd bs=1 if=$outtmp skip=6036) > $outcomp
        #rm -f -r $outtmp
        #mv $outtmp.xref $outcomp.xref
        outfile=$outcomp
}


function makeblitz() {
#compile with Runtime Code
        local blitzfile=${outfile}
        outcomp=c-${blitzfile}
#        echo "Outcomp:"$outcomp
        rm -f -r $outcomp && rm -f -r $outcomp.xref
        ${BLITZ} -c $ctype -o $outcomp $blitzfile
        outfile=$outcomp
}


function bpp2bas() {
        local bppfile=${infile}
        local outbas=${infile%bpp}bas
        rm -f -r $outbas
        ${BPP} < ${bppfile} | sed 's/£/\\/g;s/←/_/g' > ${outbas}
}

function translate() {
        local basfile=${infile%bpp}
        basfile=${basfile%bas}bas
        local outprg=${basfile%bas}prg
        #rm -f -r $outbas && rm -f -r $outprg && rm -f -r $outprg.xref
        petcat -w2 -c -o ${outprg} -- ${basfile}
        outfile=${outprg}
}

function crunch() {
        local exofile=${outfile}
#        echo "exofile:"$exofile
        crunchfile=${outfile%.prg}.exo.prg
#        echo "crunchfile:"$crunchfile
        rm -f -r $crunchfile
        ${EXO} sfx basic $exofile -o $crunchfile
        outfile=$crunchfile
}

function floppy() {
        local diskfile=${outfile}
        echo "Diskfile:"$diskfile
        local outimg=${outfile##*c-}
        local outcru=${crunchfile##*c-}
#        local outxref=${diskfile##*c-}
        local outxref=${diskfile%%.*}.prg.xref

        echo "XREF:"$outxref
        rm -f -r ${outimg%%.*}.d64
        #echo "Compiled InFile: "$infile
        #echo "Image name: "${outimg%.*}.d64
        c1541 -disable-libdebug-output -format "cbase,01" d64 ${outimg%.*}.d64 -attach ${outimg%.*}.d64 -write ${diskfile} "c-"${outimg%.prg} -write ${outxref} "z/"${outxref##*c-}
#        if ${crunchfile} <>""; then
#            c1541 -write ${crunchfile} "c-"${outcru%.prg}
#        fi
}

#make .bas file
bpp2bas
#petcat .bas to Basic .prg
translate
#1st Blitz run
makeblitz $outfile
#prepare asm source file
#remove old assemble base adress
sed -i '4d' /home/larry/C64/KickAssembler/cbase/boot-ml.asm
#set new adress
sed -i '3a\*\=\$'"$(python3 /home/larry/C64/bbs/larrymod/scripts/getaddr.py)" /home/larry/C64/KickAssembler/cbase/boot-ml.asm
#assemble KickAss Source
java -jar /home/larry/C64/KickAssembler/KickAss.jar /home/larry/C64/KickAssembler/cbase/boot-ml.asm
#remove load adress bytes from ML file
dd bs=1 if=/home/larry/C64/KickAssembler/cbase/boot-ml.prg skip=2 of=/home/larry/C64/KickAssembler/cbase/boot-ml2.prg
#merge Basic Code with ML Code
cat /home/larry/C64/bbs/larrymod/src/larry-boot.prg /home/larry/C64/KickAssembler/cbase/boot-ml2.prg > /home/larry/C64/bbs/larrymod/src/larry-boot2.prg
#set new outfile variable
outfile=larry-boot2.prg
echo "Outfile:" $outfile
#2nd Blitz run
makeblitz $outfile
