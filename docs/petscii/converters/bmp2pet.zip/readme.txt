

BMP2PET - 2013 Algorithm - Build 2 - 23/10/2013
-----------------------------------------------

This is the second build of the raw2pet petscii converter with the following additional features.

Removed RAW load option.  Can now load images in .bmp format.  Minimum screen size should be 320x200.  Anything higher than this will be cropped to the top left hand corner.

Saves Previews in Bitmap format (instead of RAW)

Higher quality conversions with higher perception based encoding.

Luminance option (Treats the 16 c64 colors as shades)

Selectable Dither (For mode options 3 and 4)

Color Curve.  Adjusts source image (that can help with higher image conversions)

For full usage, run the program without parameters.

Any comments or info, contact me
