/**************************************************************************
 *
 * FILE  system.h
 * Copyright (c) 2017, 2018 Daniel Kahlin <daniel@kahlin.net>
 * Written by Daniel Kahlin <daniel@kahlin.net>
 *
 * DESCRIPTION
 *   System structure: memory, I/O logic
 *
 ******/
#ifndef SYSTEM_H
#define SYSTEM_H

#include <stdint.h>

#include "embed_load.h"
#include "fake6502/wrap6502.h"

void init_system(void);

/* raw accessors */
uint8_t readram(uint16_t address);
void writeram(uint16_t address, uint8_t value);

int load_ram_emb(Embedded *emb, int ad, uint16_t *sap, uint16_t *eap, uint16_t *lap);


extern uint8_t read6502(uint16_t address);
extern void write6502(uint16_t address, uint8_t value);


#endif /* SYSTEM_H */
/* eof */
