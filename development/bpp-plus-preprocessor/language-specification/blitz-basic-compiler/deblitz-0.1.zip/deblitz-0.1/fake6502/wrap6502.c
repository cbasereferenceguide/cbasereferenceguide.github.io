/**************************************************************************
 *
 * FILE  wrap6502.c
 * Copyright (c) 2017 Daniel Kahlin <daniel@kahlin.net>
 * Written by Daniel Kahlin <daniel@kahlin.net>
 *
 * DESCRIPTION
 *   Wrapper with accessors for fake6502.c.
 *
 ******/
#include <stdint.h>

//6502 CPU registers
extern uint16_t pc;
extern uint8_t sp, a, x, y, status;

//helper variables
extern uint32_t instructions;
extern uint32_t clockticks6502;


uint32_t get6502ticks(void)
{
    return clockticks6502;
}

uint32_t get6502count(void)
{
    return instructions;
}

uint16_t get6502pc(void)
{
    return pc;
}
void set6502pc(uint16_t val)
{
    pc = val;
}

uint8_t get6502sp(void)
{
    return sp;
}
void set6502sp(uint8_t val)
{
    sp = val;
}

uint8_t get6502acc(void)
{
    return a;
}
void set6502acc(uint8_t val)
{
    a = val;
}

uint8_t get6502x(void)
{
    return x;
}
void set6502x(uint8_t val)
{
    x = val;
}

uint8_t get6502y(void)
{
    return y;
}
void set6502y(uint8_t val)
{
    y = val;
}

uint8_t get6502sr(void)
{
    return status;
}
void set6502sr(uint8_t val)
{
    status = val;
}


/* eof */
