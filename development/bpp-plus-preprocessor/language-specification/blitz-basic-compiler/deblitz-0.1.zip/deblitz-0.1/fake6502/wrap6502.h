/**************************************************************************
 *
 * FILE  wrap6502.h
 * Copyright (c) 2017 Daniel Kahlin <daniel@kahlin.net>
 * Written by Daniel Kahlin <daniel@kahlin.net>
 *
 * DESCRIPTION
 *   Wrapper with accessors for fake6502.c.
 *
 ******/
#ifndef WRAP6502_H
#define WRAP6502_H

#include <stdint.h>

/* fake6502.c functions */
void nmi6502(void);
void irq6502(void);
void reset6502(void);
void exec6502(uint32_t tickcount);
void step6502(void);
void hookexternal(void *funcptr);

/* accessor wrappers */
uint32_t get6502ticks(void);
uint32_t get6502count(void);

uint16_t get6502pc(void);
void set6502pc(uint16_t val);

uint8_t get6502sp(void);
void set6502sp(uint8_t val);

uint8_t get6502acc(void);
void set6502acc(uint8_t val);

uint8_t get6502x(void);
void set6502x(uint8_t val);

uint8_t get6502y(void);
void set6502y(uint8_t val);

uint8_t get6502sr(void);
void set6502sr(uint8_t val);

#endif /* WRAP6502_H */
/* eof */
