/**************************************************************************
 *
 * FILE  embed_load.c
 * Copyright (c) 2018 Daniel Kahlin <daniel@kahlin.net>
 * Written by Daniel Kahlin <daniel@kahlin.net>
 *
 * DESCRIPTION
 *   Loader for embedded files.
 *
 ******/
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

#include "embed_load.h"


/**************************************************************************
 *
 * NAME  reset_embedded()
 *
 * DESCRIPTION
 *   initialize emulation embed_load
 *
 ******/
void reset_embedded(Embedded *emb)
{
    emb->pos = 0;
}


/**************************************************************************
 *
 * NAME  get_embedded()
 *
 * DESCRIPTION
 *   initialize emulation embed_load
 *
 ******/
int get_embedded(Embedded *emb)
{
    size_t i;

    if (emb->pos >= emb->len) {
	return EOF;
    }

    i = emb->pos;
    emb->pos++;

    return emb->data[i] ^ (i & 0xff);
}


/**************************************************************************
 *
 * NAME  load_embedded()
 *
 * DESCRIPTION
 *   initialize emulation embed_load
 *
 ******/
size_t load_embedded(Embedded *emb, uint8_t *dest)
{
    size_t i = 0;
    int c;
    reset_embedded(emb);
    while ( c = get_embedded(emb), c != EOF ) {
	*dest++ = c;
	i++;
    }

    return i;
}


/* eof */
