/**************************************************************************
 *
 * FILE  helpers.h
 * Copyright (c) 2017, 2018 Daniel Kahlin <daniel@kahlin.net>
 * Written by Daniel Kahlin <daniel@kahlin.net>
 *
 * DESCRIPTION
 *   Support functions for hooking into various programs.
 *
 ******/
#ifndef HELPERS_H
#define HELPERS_H

#include <stdint.h>

#include "buffer.h"

void do_clc(void);
void do_rts(void);

void init_read(Buffer *bf);
uint8_t do_read(void);
void init_write(Buffer *bf);
void do_write(uint8_t c);

int load_buffer(Buffer *bf, int ad, uint16_t *sap, uint16_t *eap, uint16_t *lap);
void save_buffer(Buffer *bf, uint16_t sa, uint16_t ea, int la);

#endif /* HELPERS_H */
/* eof */
