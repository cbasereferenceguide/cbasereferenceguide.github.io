/**************************************************************************
 *
 * FILE  iosys.c
 * Copyright (c) 2018 Daniel Kahlin <daniel@kahlin.net>
 * Written by Daniel Kahlin <daniel@kahlin.net>
 *
 * DESCRIPTION
 *   Simple I/O and file system emulation
 *
 ******/
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

#include "buffer.h"
#include "global.h"
#include "helpers.h"
#include "iosys.h"
#include "system.h"
#include "utils.h"


/**************************************************************************
 *
 * SECTION  file system
 *
 * DESCRIPTION
 *   Simple file system emulation
 *
 ******/
static int num_files = 0;
static cbm_files_t file_list[16];

void add_file(char *name, char type, int mode, Buffer *bf)
{
    int n = num_files;
    file_list[n].name = name;
    file_list[n].mode = mode;
    file_list[n].type = type;
    file_list[n].bf = bf;
    num_files = n + 1;
}


typedef struct {
    int dev;
    int sec;
    Buffer *bf;
} cbm_file_t;

static cbm_file_t open_file[16];
static int cur_in_dev = 0;
static int cur_out_dev = 3;


void init_read_file(int n, Buffer *bf)
{
    open_file[n].bf = bf;
    open_file[n].bf->pos = 0;
    write6502(0x90, 0x00);
}

static uint8_t do_read_file(void)
{
    uint8_t c;
    Buffer *bf = open_file[cur_in_dev].bf;

    c = bf->buf[bf->pos];
    bf->pos++;
    if (bf->pos == bf->len) {
	write6502(0x90, 0x40);
    }

    return c;
}


void init_write_file(int n, Buffer *bf)
{
    open_file[n].bf = bf;
    open_file[n].bf->pos = 0;
    open_file[n].bf->len = 0;
    write6502(0x90, 0x00);
}

void do_write_file(uint8_t c)
{
    Buffer *bf = open_file[cur_out_dev].bf;

    bf->buf[bf->pos] = c;
    bf->pos++;
    bf->len++;
}

typedef struct {
    char *name;
    int drive;
    char type;
    char mode;
} filename_t;


filename_t parse_filename(char *name)
{
    filename_t f;
    char *p = name;
    char *p2;

    /* defaults */
    f.drive = 0;
    f.type = 'p';
    f.mode = '?';

    p2 = strchr(p, ':');
    if (p2) {
	f.drive = atoi(p);
	p = p2 + 1;
    }
    f.name = p;

    p2 = strchr(p, ',');
    if (p2) {
	p = p2;
	*p++ = 0;
	f.type = *p++;
	p2 = strchr(p, ',');
	if (p2) {
	    p = p2;
	    *p++ = 0;
	    f.mode = *p++;
	}
    }
    return f;
}


/**************************************************************************
 *
 * SECTION  screen system
 *
 * DESCRIPTION
 *   Simple screen I/O emulation with scraping hooks
 *
 ******/
int convert_petscii(int c)
{
    if (c >= 0x41 && c <= 0x5f) {
	c += 0x20;
    } else if (c >= 0xc1 && c <= 0xdf) {
	c &= 0x7f;
    }

    if (c == '\r') {
        c = '\n';
    }

    return c;
}


static int wrap = 40;
static int xpos = 0;


static int lineout_cnt = 0;
static char lineout_buf[256];

static int linein_pos = 0;
static char linein_buf[256] = "";


static in_hook_t in_hook = 0;
static void *in_hook_user = 0;

static void add_char(int c)
{
    lineout_buf[lineout_cnt++] = c;
}


void set_linein(char *str)
{
    linein_pos = 0;
    strcpy(linein_buf, str);
}


void set_in_hook(in_hook_t hook, void *user)
{
    in_hook = hook;
    in_hook_user = user;
}


static int print_flag = 1;

void set_print_mode(int m)
{
    print_flag = m;
}

static void flush_line(void)
{
    int i;

    /* zero terminate string */
    lineout_buf[lineout_cnt] = 0;


    /* handle pattern matching */
    if (in_hook) {
	int c;
	c = (in_hook)(lineout_buf, in_hook_user);

	if (c) {
	    lineout_cnt = 0;
	    return;
	}
    }

    if (print_flag) {
	/* print string if any */
	for (i = 0; i < lineout_cnt; i++) {
	    int c = lineout_buf[i];

	    putchar(c);
	    if (c == '\r') {
		fflush(stdout);
	    }
	}
    }

    lineout_cnt = 0;
}


static void chrout_screen(int c)
{
    static int last_c;

    /* parse colors */
    switch (c) {
    case 0x05:
	/* 1 white */
	return;
    case 0x1c:
	/* 2 red */
	return;
    case 0x1e:
	/* 5 green */
	return;
    case 0x1f:
	/* 6 blue */
	return;
    case 0x82:
	/* 8 brown */
	return;
    case 0x90:
	/* 0 black */
	return;
    case 0x95:
	/* 9 orange */
	return;
    case 0x96:
	/* 10 lt red */
	return;
    case 0x97:
	/* 11 dark grey */
	return;
    case 0x98:
	/* 12 grey */
	return;
    case 0x99:
	/* 13 lt green */
	return;
    case 0x9a:
	/* 14 lt blue */
	return;
    case 0x9b:
	/* 15 lt grey */
	return;
    case 0x9c:
	/* 4 purple */
	return;
    case 0x9e:
	/* 7 yellow */
	return;
    case 0x9f:
	/* 3 cyan */
	return;
    default:
	break;
    }

    switch (c) {
    case 0x93:
	/* ignore CLR */
	return;
    case 0x0e:
	/* ignore case? */
	return;
    case 0x0a:
	/* ignore LF */
	return;
    case 0x91:
	/* CRSR up */
	last_c = 0x91;
	return;
    case 0x11:
	/* CRSR down */
	c = 0x0a;
	break;
    case 0x1d:
	/* CRSR right */
	c = ' ';
	break;
    case 0x0d:
	if (last_c != 0x91) {
	    c = 0x0a;
	}
	break;
    default:
	break;
    }
    last_c = c;

    if (c >= 0x41 && c <= 0x5f) {
	c += 0x20;
    } else if (c >= 0xc1 && c <= 0xdf) {
	c &= 0x7f;
    }

    add_char(c);

    switch (c) {
    case '\r':
    case '\n':
	flush_line();
        xpos = 0;
	break;
    default:
	xpos++;
	if (xpos == wrap) {
	    add_char('\n');
	    xpos = 0;
	}
	break;
    }
}


static int chrin_screen(void)
{
    int c;

    if (linein_buf[linein_pos] == 0) {
	flush_line();
	linein_pos = 0;
	if (linein_buf[linein_pos] == 0) {
	    panic("no response for input");
	}
    }

    c = linein_buf[linein_pos++];

    if (c == '\r') {
	linein_pos = 0;
	linein_buf[linein_pos] = 0;
    }

    return c;
}





/**************************************************************************
 *
 * SECTION  kernal wrappers
 *
 * DESCRIPTION
 *   Default kernal routine wrappers
 *
 ******/
void kernal_plot(void)
{
    /* only handle read xpos. ypos is always 0. write does nothing */
    if (get6502sr() & 0x01) {
	set6502y(xpos);
	set6502x(0);
    }
    do_rts();
}


void kernal_chrout(void)
{
    int c;
    c = get6502acc();

    if (cur_out_dev == 3) {
	chrout_screen(c);
    } else if (cur_out_dev == 15) {
	/* do nothing */
    } else {
	do_write_file(c);
    }
    do_clc();
    do_rts();
}

static int state15 = 0;

void kernal_chrin(void)
{
    int c;

    if (cur_in_dev == 0) {
	c = chrin_screen();
    } else if (cur_in_dev == 15) {
	char *pass = "00, OK,00,00\r";
	c = pass[state15++];
	if (c == '\r') {
	    state15 = 0;
	}
    } else {
	c = do_read_file();
    }

    set6502acc(c);
    do_clc();
    do_rts();
}

void kernal_open(void)
{
    int c;
    int l, i;
    uint16_t ad;
    char name[256];

    l = read6502(0xb7);
    ad = read6502(0xbb) | (read6502(0xbc) << 8);
    for (i = 0; i < l; i++) {
	c = read6502(ad + i);
	if (c >= 0x41 && c <= 0x5f) {
	    c += 0x20;
	} else if (c >= 0xc1 && c <= 0xdf) {
	    c &= 0x7f;
	}
	name[i] = c;
    }
    name[i] = 0;

    int fn = read6502(0xb8);
    int dev = read6502(0xba);
    int sa = read6502(0xb9);

    //printf("open: '%s', %d, %d, %d\n", name, fn, dev, sa);

    if (dev == 8 && sa == 15) {
	state15 = 0;
    }


    /* parse file name */
    filename_t f = parse_filename(name);
    if (debug_g) {
	printf("%d:'%s',%c,%c\n", f.drive, f.name, f.type, f.mode);
    }

    Buffer *bf = 0;
    for (i = 0; i < num_files; i++) {
	if (!strcmp(f.name, file_list[i].name) && f.type == file_list[i].type) {
	    bf = file_list[i].bf;
	    break;
	}
    }

    if (f.mode == 'r') {
	init_read_file(fn, bf);
    }
    if (f.mode == 'w') {
	init_write_file(fn, bf);
    }

    do_clc();
    do_rts();
}

void kernal_close(void)
{
    //printf("close %d\n", get6502acc());
    do_clc();
    do_rts();
}

void kernal_clall(void)
{
    //printf("clall\n");
    /* closes files, the falls through into clrchn */
    kernal_clrchn();
}

void kernal_chkin(void)
{
    int chn = get6502x();
    cur_in_dev = chn;
    //printf("chkin %d\n", chn);
    do_clc();
    do_rts();
}

void kernal_chkout(void)
{
    int chn = get6502x();
    cur_out_dev = chn;
    //printf("chkout %d\n", chn);
    do_clc();
    do_rts();
}

void kernal_clrchn(void)
{
    //printf("clrchn\n");

    cur_in_dev = 0;
    cur_out_dev = 3;

    /*
     * some programs seem to rely on the return values here.
     * the Blitz! runtime seems to rely on the acc being $00.
     */
    set6502x(3);
    set6502acc(0);
    /* flags should be set according to the LDA #$00, carry is normally set */

    do_rts();
}




/* eof */
