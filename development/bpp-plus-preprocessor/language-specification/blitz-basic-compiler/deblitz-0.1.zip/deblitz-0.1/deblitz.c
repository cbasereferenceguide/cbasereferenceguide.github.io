/**************************************************************************
 *
 * FILE  deblitz.c
 * Copyright (c) 2018 Daniel Kahlin <daniel@kahlin.net>
 * Written by Daniel Kahlin <daniel@kahlin.net>
 *
 * DESCRIPTION
 *   Wrapper for the Austrospeed/Blitz! decompiler
 *
 ******/
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "buffer.h"
#include "deblitz_bin.h"
#include "embed_load.h"
#include "global.h"
#include "helpers.h"
#include "iosys.h"
#include "system.h"
#include "utils.h"


#define PROGRAM "deblitz"

const char program_g[] = PROGRAM;

#define TICK_LIMIT (10000000000)

void do_deblitz(const char *srcname, const char *destname, int compact);


int main(int argc, char *argv[])
{
    int c;
    char *srcname = 0;
    char *destname = "a.prg";
    int compact;

    /* defaults */
    verbose_g = 0;
    debug_g = 0;
    compact = 0;


    /*
     * scan for valid options
     */
    while (EOF != (c = getopt(argc, argv, "co:qvdVhH"))) {
        switch (c) {

	/* a missing parameter */
	case ':':
	/* an illegal option */
	case '?':
	    exit(1);

	/* set quiet mode */
	case 'q':
	    verbose_g = 0;
	    break;

	/* set verbose mode */
	case 'v':
	    verbose_g++;
	    break;

	/* set debug mode */
	case 'd':
	    debug_g = 1;
	    break;

	/* print version */
	case 'V':
	    fprintf (stdout, PROGRAM " " VERSION "\n");
	    exit(0);

	/* print help */
	case 'h':
	    fprintf(stderr,
PROGRAM " " VERSION ": Blitz!/Austro-Speed decompiler\n"
"Written 2018 by Daniel Kahlin <daniel@kahlin.net>\n"
"\n"
"The original c64 decompiler contained within is:\n"
"  The Blitz!/Austro-Speed Decompiler! 3.2\n"
"  Debugged/Enhanced 1991 by Mark Dickenson\n"
"           Enhanced 2008 by iAN CooG/HF\n"
"           Debugged 2016 by Flavioweb/HF\n"
"\n"
"usage: " PROGRAM " [OPTION] FILE...\n"
"\n"
"Valid options:\n"
"    -c              compact output\n"
"    -o<name>        output file\n"
"    -q              be quiet\n"
"    -v              be verbose (can be multiple)\n"
"    -d              display debug information\n"
"    -h              displays this help text\n"
"    -H              display original c64 documentation by Mark Dickenson\n"
"    -V              output program version\n"
	    );
	    exit(0);

	/* print original docs */
	case 'H':
	    reset_embedded(&decompdoc_emb);
	    while ( c = get_embedded(&decompdoc_emb), c != EOF) {
		putchar(convert_petscii(c));
	    }
	    exit(0);

	/* set compact mode */
	case 'c':
	    compact = 1;
	    break;

	/* set destination name */
	case 'o':
	    destname = optarg;
	    break;

	/* default behavior */
	default:
	    break;
	}
    }

    /*
     * optind now points at the first non option argument
     */
    int num_files = argc - optind;
    if (num_files < 1) {
	panic("too few arguments");
    }
    if (num_files > 1) {
	panic("too many arguments");
    }
    srcname = argv[optind];

    do_deblitz(srcname, destname, compact);

    exit(0);
}




Buffer *in_bf;
Buffer *out_bf;
Buffer *data_bf;
Buffer *cmp_bf;
Buffer *ml_bf;

static void run_until_rts(uint16_t addr)
{
    uint8_t sp = get6502sp();
    set6502pc(addr);

    while (1) {
	uint16_t pc;

	pc = get6502pc();
	if (read6502(pc) == 0x60 && get6502sp() == sp) {
	    //printf("%04x\n", pc);
	    break;
	}
	step6502();
    }
}

static void run_bp(uint16_t addr)
{
    while (get6502ticks() < TICK_LIMIT) {
	uint16_t pc;

	//printf("%04X\n", get6502pc());
	step6502();
	pc = get6502pc();
	if (pc == addr) {
	    break;
	}
	switch (pc) {
	case 0xffd2:
	    kernal_chrout();
	    break;
	case 0xffcf:
	    kernal_chrin();
	    break;
	case 0xffc0:
	    kernal_open();
	    break;
	case 0xffc6:
	    kernal_chkin();
	    break;
	case 0xffcc:
	    kernal_clrchn();
	    break;
	case 0xffc3:
	    kernal_close();
	    break;
	case 0xffc9:
	    kernal_chkout();
	    break;
	case 0xffe7:
	    kernal_clall();
	    break;
	case 0xffe4:
	    kernal_chrin();
	    break;
	case 0xfff0:
	    kernal_plot();
	    break;
	case 0x0000:
	    printf("out!\n");
	    exit(1);
	    break;
	default:
	    break;
	}

    }

}

static void run_until_bp(uint16_t addr, uint16_t bp)
{
    set6502pc(addr);
    run_bp(bp);
}



typedef struct {
    int compact;
} User;


int in_hook(char *str, void *user)
{
    static int state = 0;
    int compact = ((User *)user)->compact;

    if (!strcmp(str, "Program Name? ")) {
	set_linein("y\r");
	//printf(">> Name\n");

	return 1;
    }
    if (!strcmp(str, "Compress Final Output? ")) {
	if (compact) {
	    set_linein("Y\r");
	} else {
	    set_linein("N\r");
	}

	//printf(">> Compress\n");

	state = 1;
	return 1;
    }
    if (state == 1) {
	if (strcmp(str, "\n")) {
	    state = 2;
	    set_print_mode(1);
	    return 0;
	}
	return 1;
    }

    return 0;
}


void do_deblitz(const char *srcname, const char *destname, int compact)
{

    in_bf = create_buffer_from_file(srcname);

    out_bf = create_buffer(0x10000);
    data_bf = create_buffer(0x10000);
    cmp_bf = create_buffer(0x10000);
    ml_bf = create_buffer(0x10000);

    add_file("y", 'p', MODE_RO, in_bf);
    add_file("y.bas", 'p', MODE_RW, out_bf);
    add_file("data", 's', MODE_RW, data_bf);
    add_file("y.cmp", 'p', MODE_WO, cmp_bf);
    add_file("y.ml", 'p', MODE_WO, ml_bf);

    /******
     *
     *
     */
    init_system();
    reset6502();

    /* initial run */
    set6502sp(0xf6);

#if 1
    run_until_rts(0xfd50);
    run_until_rts(0xfd15);
    run_until_rts(0xe453);
    run_until_rts(0xe3bf);
#else
    set6502pc(0xfd50);
    run_bp(0xfd9a);
    set6502pc(0xfd15);
    run_bp(0xfd2f);
    set6502pc(0xe453);
    run_bp(0xe45e);
    set6502pc(0xe3bf);
    run_bp(0xe421);
#endif
    run_until_bp(0xa644, 0xa68d);

    uint16_t ea;
    load_ram_emb(&decomp_emb, -1, 0, &ea, 0);

    write6502(0x02d, ea & 0xff);
    write6502(0x02e, ea >> 8);

    /* initial run */
    set6502sp(0xf6);

    run_until_bp(0xa52a, 0xa480);
    //    set6502pc(0xa7ae);
    // run_bp(0x0001);

    //    save_file("a.prg", 0x0000, 0x0000, -1);


    User user = {
	compact = compact
    };
    set_in_hook(in_hook, &user);
    set_print_mode(0);

    //printf("-----------------------------------------\n");
    run_until_bp(0x0400, 0xa474);
    //printf("-----------------------------------------\n");

    /* free input buffer */
    destroy_buffer(in_bf);

    if (debug_g) {
	/* write out temporaries */
	write_buffer_to_file(data_bf, "a_data.prg");
    }

    /* free temporary buffer */
    destroy_buffer(data_bf);

    /* write out binaries */
    if (!compact) {
	write_buffer_to_file(out_bf, destname);
    } else {
	char name[256];
	strncpy(name, destname, sizeof(name));
	strncat(name, ".orig", sizeof(name));
	write_buffer_to_file(out_bf, name);

	write_buffer_to_file(cmp_bf, destname);
    }
    if (ml_bf->len > 0) {
	char name[256];
	strncpy(name, destname, sizeof(name));
	strncat(name, ".ml", sizeof(name));
	write_buffer_to_file(ml_bf, name);
    }

    /* free output buffers */
    destroy_buffer(out_bf);
    destroy_buffer(ml_bf);
    destroy_buffer(cmp_bf);

    exit(0);
}


/* eof */
