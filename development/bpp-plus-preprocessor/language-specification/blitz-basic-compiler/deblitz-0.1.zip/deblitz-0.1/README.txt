deblitz 0.1 - Blitz!/Austro-Speed decompiler

DESCRIPTION
  deblitz is a cross decompiler for Blitz!/Austro-Speed compiled programs
written by Daniel Kahlin <daniel@kahlin.net>.

The original c64 decompiler contained within is:
  The Blitz!/Austro-Speed Decompiler! 3.2
  Debugged/Enhanced 1991 by Mark Dickenson
           Enhanced 2008 by iAN CooG/HF
           Debugged 2016 by Flavioweb/HF


USAGE
  usage: deblitz [OPTION] FILE...

  Valid options:
      -c              compact output
      -o<name>        output file
      -q              be quiet
      -v              be verbose (can be multiple)
      -d              display debug information
      -h              displays this help text
      -H              display original c64 documentation by Mark Dickenson
      -V              output program version

The difference to the original decompiler is that the output filename is
always the one specified with the -o option, even though -c is seleteced.
The uncompacted program will instead end up in <filename>.orig.

eof
