/**************************************************************************
 *
 * FILE  iosys.h
 * Copyright (c) 2018 Daniel Kahlin <daniel@kahlin.net>
 * Written by Daniel Kahlin <daniel@kahlin.net>
 *
 * DESCRIPTION
 *   Simple I/O and file system emulation
 *
 ******/
#ifndef IOSYS_H
#define IOSYS_H

#include "buffer.h"

/******
 * file system
 */
#define MODE_RO (1<<0)
#define MODE_WO (1<<1)
#define MODE_RW (MODE_RO | MODE_WO)

void add_file(int dev, int drive, char *name, char type, int mode, Buffer *bf);


/******
 * screen system
 */
int convert_petscii(int c);

typedef int (*in_hook_t)(char *, void *);

void set_in_hook(in_hook_t hook, void *user);
void set_linein(char *str);
void set_print_mode(int m);

/******
 * kernal wrappers
 */
void kernal_plot(void);
void kernal_chrout(void);
void kernal_chrin(void);
void kernal_open(void);
void kernal_close(void);
void kernal_clall(void);
void kernal_chkin(void);
void kernal_chkout(void);
void kernal_clrchn(void);

#endif /* IOSYS_H */
/* eof */
