/**************************************************************************
 *
 * FILE  helpers.c
 * Copyright (c) 2017, 2018 Daniel Kahlin <daniel@kahlin.net>
 * Written by Daniel Kahlin <daniel@kahlin.net>
 *
 * DESCRIPTION
 *   Support functions for hooking into various programs.
 *
 ******/
#include <stdio.h>
#include <stdint.h>

#include "buffer.h"
#include "helpers.h"
#include "system.h"


void do_clc(void)
{
    set6502sr(get6502sr() & 0xfe);
}

void do_rts(void)
{
    uint8_t sp;
    uint16_t pc;

    sp = get6502sp();
    sp++;
    pc = read6502(0x100+sp);
    sp++;
    pc |= read6502(0x100+sp) << 8;

    set6502sp(sp);
    set6502pc(pc + 1);
}



Buffer *bf_r;

void init_read(Buffer *bf)
{
    bf_r = bf;

    bf_r->pos = 0;
    write6502(0x90, 0x00);
}

uint8_t do_read(void)
{
    uint8_t c;
    c = bf_r->buf[bf_r->pos];
    bf_r->pos++;
    if (bf_r->pos == bf_r->len) {
	write6502(0x90, 0x40);
    }

    return c;
}

Buffer *bf_w;

void init_write(Buffer *bf)
{
    bf_w = bf;
    bf_w->pos = 0;
    bf_w->len = 0;
    write6502(0x90, 0x00);
}

void do_write(uint8_t c)
{
    bf_w->buf[bf_w->pos] = c;
    bf_w->pos++;
    bf_w->len++;
}


int load_buffer(Buffer *bf, int ad, uint16_t *sap, uint16_t *eap, uint16_t *lap)
{
    int c;
    int n;
    uint16_t la, sa, ea;

    init_read(bf);

    la = do_read() | (do_read() << 8);
    n = 0;
    if (ad < 0) {
	ad = la;
    }
    sa = ad;
    do {
	c = do_read();
	writeram(ad, c);
	ad++;
	n++;
    } while (read6502(0x90) == 0);
    ea = ad;

    if (sap) {
	*sap = sa;
    }
    if (eap) {
	*eap = ea;
    }
    if (lap) {
	*lap = la;
    }

    return n;
}


void save_buffer(Buffer *bf, uint16_t sa, uint16_t ea, int la)
{
    int i;
    int l = ea - sa;

    if (ea == 0x0000) {
	l = 0x10000 - sa;
    }

    if (la < 0) {
	la = sa;
    }

    init_write(bf);
    do_write(la & 0xff);
    do_write(la >> 8);
    for (i = 0; i < l; i++) {
	do_write(readram(sa + i));
    }
}

/* eof */
