/**************************************************************************
 *
 * FILE  system.c
 * Copyright (c) 2017, 2018 Daniel Kahlin <daniel@kahlin.net>
 * Written by Daniel Kahlin <daniel@kahlin.net>
 *
 * DESCRIPTION
 *   System structure: memory, I/O logic
 *
 ******/
#include <stdio.h>
#include <stdint.h>
#include <string.h>

#include "embed_load.h"
#include "nu6502/nu6502.h"


#include "system_bin.h"
static uint8_t basic_rom[0x2000];
static uint8_t kernal_rom[0x2000];

static uint8_t memory[0x10000];


/**************************************************************************
 *
 * NAME  init_system()
 *
 * DESCRIPTION
 *   initialize emulation system
 *
 ******/
void init_system(void)
{
    load_embedded(&basic_emb, basic_rom);
    load_embedded(&kernal_emb, kernal_rom);
}


/**************************************************************************
 *
 * NAME  readram(), writeram()
 *
 * DESCRIPTION
 *   read and write ram functions.
 *
 ******/
uint8_t readram(uint16_t address)
{
    return memory[address];
}

void writeram(uint16_t address, uint8_t value)
{
    memory[address] = value;
}


/**************************************************************************
 *
 * NAME  read6502(), write6502()
 *
 * DESCRIPTION
 *   Main 6502 read and write function.
 *
 ******/
uint8_t cpu00 = 0x2f;
uint8_t cpu01 = 0x37;
uint8_t vicii[0x40];

uint8_t read6502(uint16_t address)
{
    if (address == 0x00) {
	return cpu00;
    } else if (address == 0x01) {
	return cpu01;
    }

    if ( (cpu01 & 0x07) == 0x07 ) {
	if ((address & 0xe000) == 0xa000) {
	    return basic_rom[address & 0x1fff];
	}
    }
    if ( (cpu01 & 0x07) == 0x07 || (cpu01 & 0x07) == 0x06 ) {
	if ((address & 0xe000) == 0xe000) {
	    return kernal_rom[address & 0x1fff];
	}
    }

    if ( (cpu01 & 0x03) ) {
	if ((address & 0xf000) == 0xd000) {
	    if ((address & 0xfc00) == 0xd000) {
		return vicii[address & 0x3f];
	    }
	    return 0x00;
	}
    }
    return memory[address];
}

void write6502(uint16_t address, uint8_t value)
{
    if (address == 0x00) {
	cpu00 = value;
    } else if (address == 0x01) {
	value &= 0x3f;
	cpu01 = value;
    }

    if ( (cpu01 & 0x03) ) {
	if ((address & 0xf000) == 0xd000) {
	    if ((address & 0xfc00) == 0xd000) {
		vicii[address & 0x3f] = value;
		return;
	    }
	    return;
	}
    }

    memory[address] = value;
}



/**************************************************************************
 *
 * NAME  load_ram_emb()
 *
 * DESCRIPTION
 *   Load embedded data into ram.
 *
 ******/
int load_ram_emb(Embedded *emb, int ad, uint16_t *sap, uint16_t *eap, uint16_t *lap)
{
    int c;
    int n;
    uint16_t la, sa, ea;

    reset_embedded(emb);

    la = get_embedded(emb) | (get_embedded(emb) << 8);
    n = 0;
    if (ad < 0) {
	ad = la;
    }
    sa = ad;
    while ( c = get_embedded(emb), c != EOF ) {
	memory[ad] = c;
	ad++;
	n++;
    }
    ea = ad;

    if (sap) {
	*sap = sa;
    }
    if (eap) {
	*eap = ea;
    }
    if (lap) {
	*lap = la;
    }

    return n;
}

/* eof */
