blitz 0.1 - Blitz!/Austro-Comp compiler

DESCRIPTION
  blitz is a cross compiler to generate Blitz!/Austro-Comp compiled programs
written by Daniel Kahlin <daniel@kahlin.net>.

The original c64 compilers contained within is:
  Blitz! 64 by Skyles Electric Works
  Austro-Comp by Commodore Buromaschinen GmbH

USAGE
  usage: blitz [OPTION] FILE...

  Valid options:
      -c<name>        compiler: blitz/austro (default: blitz)
      -p              generate pcode only
      -i              generate interpreter only
      -o<name>        output file
      -q              be quiet
      -v              be verbose (can be multiple)
      -d              display debug information
      -h              displays this help text
      -H              display original c64 documentation by DOC'S "R" US BBS
      -V              output program version


NOTES ON VARIANTS
  There exists a number of variants of these compilers.  The Blitz! 64 one
is probably the one with the least variants.  Austro-Comp has a number of
variants with slightly different runtimes.  The one included here is the one
recently released by master.  Choosen because it came with the original
unmodified E1 and E2 variants.

REQUEST
  Please, if you have original disk images of Blitz!/Austro-Speed/Austro-Comp
send a copy  to me so I can intergrate the relevant versions into this tool.

THANKS
  - Larry (testing on target + plum's blitz)
  - Ian C00g (provided several compiler variants)
  - pcollins/excess (feedback on which compiler to use on C*Base)

HISTORY
  blitz 0.1, 2018-12-28
    - initial release

eof
