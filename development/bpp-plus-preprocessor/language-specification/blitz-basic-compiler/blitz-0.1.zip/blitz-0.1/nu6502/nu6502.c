/**************************************************************************
 *
 * FILE  nu6502.c
 * Copyright (c) 2018 Daniel Kahlin <daniel@kahlin.net>
 * Written by Daniel Kahlin <daniel@kahlin.net>
 *
 * DESCRIPTION
 *   6502 emulator
 *
 ******/
#include <stdint.h>
#include <stdio.h>

#include "nu6502.h"

#define NU6502_FAST_ACCESSORS
#define NU6502_STATIC_STATE_STRUCT

#define LXA_CONST 0xee
#define ANE_CONST 0xee

#ifdef NU6502_FAST_ACCESSORS
#define READ6502(cs, ad) read6502(ad)
#define WRITE6502(cs, ad, val) write6502(ad, val)
#else
#define READ6502(cs, ad) (cs->readfunc)(cs, ad)
#define WRITE6502(cs, ad, val) (cs->writefunc)(cs, ad, val)
#endif


#ifdef NU6502_STATIC_STATE_STRUCT
static nu6502_state_t cpu_state;
static nu6502_state_t *const cs = &cpu_state;
#endif


typedef void (*do_t)(nu6502_state_t *);
typedef void (*op_t)(nu6502_state_t *);


/**************************************************************************
 *
 * SECTION  addressing modes
 *
 * DESCRIPTION
 *   Functions to handle addressing modes
 *
 ******/
static uint8_t fetch_operand(nu6502_state_t *cs)
{
    return READ6502(cs, cs->ea);
}

static void store_operand(nu6502_state_t *cs, uint8_t val)
{
    WRITE6502(cs, cs->ea, val);
    /* there is never a conditional penalty for store operations */
    cs->penalty = 0;
}

static int core_penalty(uint16_t a1, uint16_t a2)
{
    return ((a1 & 0xff00) != (a2 & 0xff00)) ? 1 : 0;
}

static void op_imp(nu6502_state_t *cs)
{
    cs->penalty = 0;
}

static void op_imm(nu6502_state_t *cs)
{
    cs->penalty = 0;
    cs->ea = cs->pc;
    cs->pc++;
}

static void op_zp(nu6502_state_t *cs)
{
    cs->penalty = 0;
    cs->ea = READ6502(cs, cs->pc);
    cs->pc++;
}

static void op_zpx(nu6502_state_t *cs)
{
    op_zp(cs);
    cs->ea = (cs->ea + cs->x) & 0xff;
}

static void op_zpy(nu6502_state_t *cs)
{
    op_zp(cs);
    cs->ea = (cs->ea + cs->y) & 0xff;
}

static void op_abs(nu6502_state_t *cs)
{
    cs->penalty = 0;
    cs->ea = READ6502(cs, cs->pc) + (READ6502(cs, cs->pc + 1) << 8);
    cs->pc += 2;
}

static void op_abx(nu6502_state_t *cs)
{
    uint16_t new_ea;
    op_abs(cs);
    new_ea = cs->ea + cs->x;

    cs->penalty = core_penalty(cs->ea, new_ea);
    cs->ea = new_ea;
}

static void op_aby(nu6502_state_t *cs)
{
    uint16_t new_ea;
    op_abs(cs);
    new_ea = cs->ea + cs->y;
    cs->penalty = core_penalty(cs->ea, new_ea);
    cs->ea = new_ea;
}

static void op_izx(nu6502_state_t *cs)
{
    cs->penalty = 0;
    uint16_t ta = (READ6502(cs, cs->pc) + cs->x) & 0xff;
    cs->ea = READ6502(cs, ta) + (READ6502(cs, (ta + 1) & 0xff) << 8);
    cs->pc++;
}

static void op_izy(nu6502_state_t *cs)
{
    uint16_t ta = READ6502(cs, cs->pc);
    uint16_t addr = READ6502(cs, ta) + (READ6502(cs, (ta + 1) & 0xff) << 8);
    cs->ea = addr + cs->y;
    cs->penalty = core_penalty(cs->ea, addr);
    cs->pc++;
}

static void op_rel(nu6502_state_t *cs)
{
    int8_t offs = READ6502(cs, cs->pc);
    cs->pc++;
    cs->ea = cs->pc + offs;
    cs->penalty = core_penalty(cs->ea, cs->pc) + 1;
}

static void op_ind(nu6502_state_t *cs)
{
    uint16_t ta = READ6502(cs, cs->pc) + (READ6502(cs, cs->pc + 1) << 8);
    cs->penalty = 0;
    cs->ea = READ6502(cs, ta) + (READ6502(cs, ((ta + 1) & 0xff) | (ta & 0xff00)) << 8);
    cs->pc += 2;
}

#if 1
/* only for SHA <abs>,Y, SHX <abs>,Y and TAS <abs>,Y */
#define op_abys op_abs
/* only for SHY <abs>,X */
#define op_abxs op_abs

/* only for SHA (<zp>),Y */
static void op_izys(nu6502_state_t *cs)
{
    uint16_t ta = READ6502(cs, cs->pc);
    cs->penalty = 0;
    cs->ea = READ6502(cs, ta) + (READ6502(cs, (ta + 1) & 0xff) << 8);
    cs->pc++;
}
#endif


/**************************************************************************
 *
 * SECTION  flags
 *
 * DESCRIPTION
 *   Functions to handle flags
 *
 ******/
#define FLAG_C  (1<<0)
#define FLAG_Z  (1<<1)
#define FLAG_I  (1<<2)
#define FLAG_D  (1<<3)
#define FLAG_B  (1<<4)
#define FLAG_CONSTANT  (1<<5)
#define FLAG_V  (1<<6)
#define FLAG_N  (1<<7)


static void update_carry(nu6502_state_t *cs, int c)
{
    cs->sr &= ~FLAG_C;
    if (c) {
	cs->sr |= FLAG_C;
    }
}

static int get_carry(nu6502_state_t *cs)
{
    return (cs->sr & FLAG_C) ? 1 : 0;
}

static void update_ovfl(nu6502_state_t *cs, int v)
{
    cs->sr &= ~FLAG_V;
    if (v) {
	cs->sr |= FLAG_V;
    }
}

static void update_flags_z(nu6502_state_t *cs, uint8_t val)
{
    if (val == 0) {
	cs->sr |= FLAG_Z;
    } else {
	cs->sr &= ~FLAG_Z;
    }
}
static void update_flags_n(nu6502_state_t *cs, uint8_t val)
{
    if (val & 0x80) {
	cs->sr |= FLAG_N;
    } else {
	cs->sr &= ~FLAG_N;
    }
}

static void update_flags_nz(nu6502_state_t *cs, uint8_t val)
{
    update_flags_n(cs, val);
    update_flags_z(cs, val);
}


static void push_stack(nu6502_state_t *cs, uint8_t val)
{
    WRITE6502(cs, 0x100 + cs->sp, val);
    cs->sp--;
}
static void push_stack16(nu6502_state_t *cs, uint16_t val)
{
    push_stack(cs, val >> 8);
    push_stack(cs, val);
}
static uint8_t pop_stack(nu6502_state_t *cs)
{
    cs->sp++;
    return READ6502(cs, 0x100 + cs->sp);
}
static uint16_t pop_stack16(nu6502_state_t *cs)
{
    return pop_stack(cs) | (pop_stack(cs) << 8);
}


/**************************************************************************
 *
 * SECTION  opcodes
 *
 * DESCRIPTION
 *   Functions to implement the opcodes.
 *
 ******/
static void do_brk(nu6502_state_t *cs)
{
    push_stack16(cs, cs->pc + 1);
    cs->sr |= FLAG_B;
    push_stack(cs, cs->sr);

    cs->sr |= FLAG_I;
    cs->pc = READ6502(cs, 0xfffe) | (READ6502(cs, 0xffff) << 8);
}

static void do_bit(nu6502_state_t *cs)
{
    uint8_t opr = fetch_operand(cs);
    cs->sr = (cs->sr & ~FLAG_Z) | ((opr & cs->acc) == 0 ? FLAG_Z : 0);
    cs->sr = (cs->sr & 0x3f) | (opr & 0xc0);
}

/******
 * RMW instructions
 */
static uint8_t core_rol(nu6502_state_t *cs, uint8_t val, int c)
{
    update_carry(cs, val & 0x80);
    val <<= 1;
    val |= c;
    update_flags_nz(cs, val);
    return val;
}

static uint8_t core_ror(nu6502_state_t *cs, uint8_t val, int c)
{
    update_carry(cs, val & 0x01);
    val >>= 1;
    val |= c << 7;
    update_flags_nz(cs, val);
    return val;
}

static void do_asl(nu6502_state_t *cs)
{
    store_operand(cs, core_rol(cs, fetch_operand(cs), 0));
}
static void do_asla(nu6502_state_t *cs)
{
    cs->acc = core_rol(cs, cs->acc, 0);
}

static void do_rol(nu6502_state_t *cs)
{
    store_operand(cs, core_rol(cs, fetch_operand(cs), get_carry(cs)));
}
static void do_rola(nu6502_state_t *cs)
{
    cs->acc = core_rol(cs, cs->acc, get_carry(cs));
}

static void do_lsr(nu6502_state_t *cs)
{
    store_operand(cs, core_ror(cs, fetch_operand(cs), 0));
}
static void do_lsra(nu6502_state_t *cs)
{
    cs->acc = core_ror(cs, cs->acc, 0);
}

static void do_ror(nu6502_state_t *cs)
{
    store_operand(cs, core_ror(cs, fetch_operand(cs), get_carry(cs)));
}
static void do_rora(nu6502_state_t *cs)
{
    cs->acc = core_ror(cs, cs->acc, get_carry(cs));
}

static void do_inc(nu6502_state_t *cs)
{
    uint8_t tmp = fetch_operand(cs);
    tmp++;
    update_flags_nz(cs, tmp);
    store_operand(cs, tmp);
}

static void do_dec(nu6502_state_t *cs)
{
    uint8_t tmp = fetch_operand(cs);
    tmp--;
    update_flags_nz(cs, tmp);
    store_operand(cs, tmp);
}

/******
 * stack operations
 */
static void do_pha(nu6502_state_t *cs)
{
    push_stack(cs, cs->acc);
}

static void do_pla(nu6502_state_t *cs)
{
    cs->acc = pop_stack(cs);
    update_flags_nz(cs, cs->acc);
}

static void do_php(nu6502_state_t *cs)
{
    cs->sr |= FLAG_CONSTANT;
    cs->sr |= FLAG_B;  /* why is this needed? */
    push_stack(cs, cs->sr);
}

static void do_plp(nu6502_state_t *cs)
{
    cs->sr = pop_stack(cs);
    cs->sr |= FLAG_CONSTANT;
}

/******
 * Program flow
 */
static void do_jmp(nu6502_state_t *cs)
{
    cs->pc = cs->ea;
}

static void do_jsr(nu6502_state_t *cs)
{
    push_stack16(cs, cs->pc - 1);

    cs->pc = cs->ea;
}

static void do_rts(nu6502_state_t *cs)
{
    cs->pc = pop_stack16(cs) + 1;
}

static void do_rti(nu6502_state_t *cs)
{
    cs->sr = pop_stack(cs);
    cs->pc = pop_stack16(cs);
}

/******
 * branches
 */
static void core_branch(nu6502_state_t *cs, int cond)
{
    if (cond) {
	cs->pc = cs->ea;
    } else {
	cs->penalty = 0;
    }
}

/* zero */
static void do_beq(nu6502_state_t *cs)
{
    core_branch(cs, cs->sr & FLAG_Z);
}
static void do_bne(nu6502_state_t *cs)
{
    core_branch(cs, !(cs->sr & FLAG_Z));
}

/* carry */
static void do_bcs(nu6502_state_t *cs)
{
    core_branch(cs, cs->sr & FLAG_C);
}
static void do_bcc(nu6502_state_t *cs)
{
    core_branch(cs, !(cs->sr & FLAG_C));
}

/* overflow */
static void do_bvs(nu6502_state_t *cs)
{
    core_branch(cs, cs->sr & FLAG_V);
}
static void do_bvc(nu6502_state_t *cs)
{
    core_branch(cs, !(cs->sr & FLAG_V));
}

/* sign */
static void do_bmi(nu6502_state_t *cs)
{
    core_branch(cs, cs->sr & FLAG_N);
}
static void do_bpl(nu6502_state_t *cs)
{
    core_branch(cs, !(cs->sr & FLAG_N));
}

/******
 * flags
 */
/* carry */
static void do_sec(nu6502_state_t *cs)
{
    cs->sr |= FLAG_C;
}
static void do_clc(nu6502_state_t *cs)
{
    cs->sr &= ~FLAG_C;
}

/* interrupt disable */
static void do_sei(nu6502_state_t *cs)
{
    cs->sr |= FLAG_I;
}
static void do_cli(nu6502_state_t *cs)
{
    cs->sr &= ~FLAG_I;
}

/* decimal mode */
static void do_sed(nu6502_state_t *cs)
{
    cs->sr |= FLAG_D;
}
static void do_cld(nu6502_state_t *cs)
{
    cs->sr &= ~FLAG_D;
}

/* overflow */
static void do_clv(nu6502_state_t *cs)
{
    cs->sr &= ~FLAG_V;
}

/******
 * ALU
 */
static void do_ora(nu6502_state_t *cs)
{
    cs->acc |= fetch_operand(cs);
    update_flags_nz(cs, cs->acc);
}

static void do_and(nu6502_state_t *cs)
{
    cs->acc &= fetch_operand(cs);
    update_flags_nz(cs, cs->acc);
}

static void do_eor(nu6502_state_t *cs)
{
    cs->acc ^= fetch_operand(cs);
    update_flags_nz(cs, cs->acc);
}

static void do_adc(nu6502_state_t *cs)
{
    uint16_t tmp;
    uint8_t opr = fetch_operand(cs);
    int carry = get_carry(cs);

    if (!(cs->sr & FLAG_D)) {
	tmp = (uint16_t)cs->acc + opr + carry;

	uint8_t of = (tmp ^ cs->acc) & (tmp ^ opr) & 0x80;
	update_ovfl(cs, of);
	update_carry(cs, tmp & 0x100);
	update_flags_nz(cs, tmp);
    } else {
	uint16_t tmp_nv;
	int ci;
	tmp = (cs->acc & 0x0f) + (opr & 0x0f) + carry;
	if (tmp > 0x09) {
	    tmp += 0x06;
	    ci = 1;
	} else {
	    ci = 0;
	}
	tmp = (tmp & 0x0f) + (cs->acc & 0xf0) + (opr & 0xf0) + (ci << 4);
	tmp_nv = tmp;
	if ((tmp & 0x1f0) > 0x90) {
	    tmp += 0x60;
	    ci = 1;
	} else {
	    ci = 0;
	}
	update_carry(cs, ci);

	update_flags_z(cs, opr + cs->acc + carry);
	update_flags_n(cs, tmp_nv);
	uint8_t of = (tmp_nv ^ cs->acc) & (tmp_nv ^ opr) & 0x80;
	update_ovfl(cs, of);
    }

    cs->acc = tmp;
}

static void do_sbc(nu6502_state_t *cs)
{
    uint16_t tmp;
    uint8_t opr = fetch_operand(cs);
    int carry = get_carry(cs);

    tmp = (uint16_t)cs->acc - opr - 1 + carry;
    int of = (tmp ^ cs->acc) & (cs->acc ^ opr) & 0x80;
    update_ovfl(cs, of);
    update_carry(cs, !(tmp & 0x100));
    update_flags_nz(cs, tmp);

    if (cs->sr & FLAG_D) {
	int ci;
	tmp = (uint16_t)(cs->acc & 0x0f) - (opr & 0x0f) - 1 + carry;
	if (tmp & 0x10) {
	    tmp -= 0x06;
	    ci = 1;
	} else {
	    ci = 0;
	}
	tmp = (tmp & 0x0f) | ((cs->acc & 0xf0) - (opr & 0xf0) - (ci << 4));
	if (tmp & 0x100) {
	    tmp -= 0x60;
	}
    }
    cs->acc = tmp;
}


/******
 * Comparison
 */
static void do_cmp(nu6502_state_t *cs)
{
    uint16_t tmp = cs->acc - fetch_operand(cs);
    update_carry(cs, !(tmp & 0x100));
    update_flags_nz(cs, tmp);
}

static void do_cpx(nu6502_state_t *cs)
{
    uint16_t tmp = cs->x - fetch_operand(cs);
    update_carry(cs, !(tmp & 0x100));
    update_flags_nz(cs, tmp);
}

static void do_cpy(nu6502_state_t *cs)
{
    uint16_t tmp = cs->y - fetch_operand(cs);
    update_carry(cs, !(tmp & 0x100));
    update_flags_nz(cs, tmp);
}


/******
 * Load instructions
 */
static void do_ldy(nu6502_state_t *cs)
{
    cs->y = fetch_operand(cs);
    update_flags_nz(cs, cs->y);
}

static void do_lda(nu6502_state_t *cs)
{
    cs->acc = fetch_operand(cs);
    update_flags_nz(cs, cs->acc);
}

static void do_ldx(nu6502_state_t *cs)
{
    cs->x = fetch_operand(cs);
    update_flags_nz(cs, cs->x);
}


/******
 * Store instructions
 */
static void do_sta(nu6502_state_t *cs)
{
    store_operand(cs, cs->acc);
}

static void do_sty(nu6502_state_t *cs)
{
    store_operand(cs, cs->y);
}

static void do_stx(nu6502_state_t *cs)
{
    store_operand(cs, cs->x);
}


/******
 * Various implied instructions
 */
static void do_txa(nu6502_state_t *cs)
{
    cs->acc = cs->x;
    update_flags_nz(cs, cs->acc);
}

static void do_tax(nu6502_state_t *cs)
{
    cs->x = cs->acc;
    update_flags_nz(cs, cs->x);
}

static void do_tya(nu6502_state_t *cs)
{
    cs->acc = cs->y;
    update_flags_nz(cs, cs->acc);
}

static void do_tay(nu6502_state_t *cs)
{
    cs->y = cs->acc;
    update_flags_nz(cs, cs->y);
}

static void do_txs(nu6502_state_t *cs)
{
    cs->sp = cs->x;
}

static void do_tsx(nu6502_state_t *cs)
{
    cs->x = cs->sp;
    update_flags_nz(cs, cs->x);
}

static void do_iny(nu6502_state_t *cs)
{
    cs->y++;
    update_flags_nz(cs, cs->y);
}

static void do_dey(nu6502_state_t *cs)
{
    cs->y--;
    update_flags_nz(cs, cs->y);
}

static void do_inx(nu6502_state_t *cs)
{
    cs->x++;
    update_flags_nz(cs, cs->x);
}

static void do_dex(nu6502_state_t *cs)
{
    cs->x--;
    update_flags_nz(cs, cs->x);
}

static void do_nop(nu6502_state_t *cs)
{
}



/******
 * undocumented ops
 *
 */
static void do_slo(nu6502_state_t *cs)
{
    do_asl(cs);
    do_ora(cs);
}

static void do_rla(nu6502_state_t *cs)
{
    do_rol(cs);
    do_and(cs);
}

static void do_sre(nu6502_state_t *cs)
{
    do_lsr(cs);
    do_eor(cs);
}

static void do_rra(nu6502_state_t *cs)
{
    do_ror(cs);
    do_adc(cs);
}

static void do_sax(nu6502_state_t *cs)
{
#if 0
    do_sta(cs);
    do_stx(cs);
#else
    store_operand(cs, cs->acc & cs->x);
#endif
}

static void do_lax(nu6502_state_t *cs)
{
    do_lda(cs);
    do_ldx(cs);
}

static void do_dcp(nu6502_state_t *cs)
{
    do_dec(cs);
    do_cmp(cs);
}

static void do_isc(nu6502_state_t *cs)
{
    do_inc(cs);
    do_sbc(cs);
}

static void do_ane(nu6502_state_t *cs)
{
    uint8_t tmp;
    tmp = cs->acc | ANE_CONST;
    tmp &= cs->x;
    tmp &= fetch_operand(cs);
    cs->acc = tmp;
    update_flags_nz(cs, tmp);
}

#if 1
static void do_lxa(nu6502_state_t *cs)
{
    uint8_t tmp;
    tmp = cs->acc | LXA_CONST;
    tmp &= fetch_operand(cs);
    cs->acc = tmp;
    cs->x   = tmp;
    update_flags_nz(cs, tmp);
}
#else
#define do_lxa do_lax
#endif

static void do_anc(nu6502_state_t *cs)
{
    do_and(cs);
    update_carry(cs, cs->acc & 0x80);
}

static void do_asr(nu6502_state_t *cs)
{
    do_and(cs);
    do_lsra(cs);
}

static void do_arr(nu6502_state_t *cs)
{
    uint8_t tmp, orig;
    int carry = get_carry(cs);
    /* some ror / adc combination */
    tmp = cs->acc & fetch_operand(cs);
    orig = tmp;

    tmp >>= 1;
    tmp |= carry << 7;
    update_flags_nz(cs, tmp);
    update_ovfl(cs, (tmp ^ orig) & 0x40);

    if (!(cs->sr & FLAG_D)) {
	update_carry(cs, tmp & 0x40);
    } else {
	if ( ((orig & 0x0f) + (orig & 0x01)) > 0x05) {
	    tmp = (tmp & 0xf0) | ((tmp + 0x06) & 0x0f);
	}
	if ( ((orig & 0xf0) + (orig & 0x10)) > 0x50) {
	    tmp = (tmp & 0x0f) | ((tmp + 0x60) & 0xf0);
	    update_carry(cs, 1);
	} else {
	    update_carry(cs, 0);
	}
    }

    cs->acc = tmp;
}

static void do_sbx(nu6502_state_t *cs)
{
    uint16_t tmp = fetch_operand(cs);
    /* simpler description possible? */
    tmp = (cs->acc & cs->x) - tmp;
    update_carry(cs, !(tmp & 0x100));
    cs->x = tmp;
    update_flags_nz(cs, tmp);
}

static void do_sha(nu6502_state_t *cs)
{
    /* pretty kludgy, requires the operand of 0x9f to be set to abs instead
       of aby and 0x93 to op_iz */
    uint8_t tmp;
    tmp = cs->acc & cs->x & ((cs->ea >> 8) + 1);

    uint16_t addr = cs->ea + cs->y;
    if ((cs->ea & 0xff) + cs->y > 0xff) {
	addr = (addr & 0xff) | (tmp << 8);
    }
    cs->ea = addr;
    store_operand(cs, tmp);
}

static void do_shx(nu6502_state_t *cs)
{
    /* pretty kludgy, requires the operand of 0x9e to be set to abs instead
       of aby */
    uint8_t tmp;
    tmp = cs->x & ((cs->ea >> 8) + 1);

    uint16_t addr = cs->ea + cs->y;
    if ((cs->ea & 0xff) + cs->y > 0xff) {
	addr = (addr & 0xff) | (tmp << 8);
    }
    cs->ea = addr;
    store_operand(cs, tmp);
}

static void do_shy(nu6502_state_t *cs)
{
    /* pretty kludgy, requires the operand of 0x9c to be set to abs instead
       of abx */
    uint8_t tmp;
    tmp = cs->y & ((cs->ea >> 8) + 1);

    uint16_t addr = cs->ea + cs->x;
    if ((cs->ea & 0xff) + cs->x > 0xff) {
	addr = (addr & 0xff) | (tmp << 8);
    }
    cs->ea = addr;
    store_operand(cs, tmp);
}

static void do_tas(nu6502_state_t *cs)
{
    /* pretty kludgy, requires the operand of 0x9b to be set to abs instead
       of aby */
    do_sha(cs);
    cs->sp = cs->acc & cs->x;
}

static void do_las(nu6502_state_t *cs)
{
    cs->sp &= fetch_operand(cs);
    cs->x = cs->sp;
    cs->acc = cs->sp;
    update_flags_nz(cs, cs->sp);
}


static void do_jam(nu6502_state_t *cs)
{
}



/**************************************************************************
 *
 * SECTION  opcodes/addressing mode tables
 *
 * DESCRIPTION
 *   pointers to modes.
 *
 ******/
static const do_t tab_mne[] = {
     do_brk,  do_ora,  do_jam,  do_slo,  do_nop,  do_ora,  do_asl,  do_slo,
     do_php,  do_ora, do_asla,  do_anc,  do_nop,  do_ora,  do_asl,  do_slo,
     do_bpl,  do_ora,  do_jam,  do_slo,  do_nop,  do_ora,  do_asl,  do_slo,
     do_clc,  do_ora,  do_nop,  do_slo,  do_nop,  do_ora,  do_asl,  do_slo,
     do_jsr,  do_and,  do_jam,  do_rla,  do_bit,  do_and,  do_rol,  do_rla,
     do_plp,  do_and, do_rola,  do_anc,  do_bit,  do_and,  do_rol,  do_rla,
     do_bmi,  do_and,  do_jam,  do_rla,  do_nop,  do_and,  do_rol,  do_rla,
     do_sec,  do_and,  do_nop,  do_rla,  do_nop,  do_and,  do_rol,  do_rla,
     do_rti,  do_eor,  do_jam,  do_sre,  do_nop,  do_eor,  do_lsr,  do_sre,
     do_pha,  do_eor, do_lsra,  do_asr,  do_jmp,  do_eor,  do_lsr,  do_sre,
     do_bvc,  do_eor,  do_jam,  do_sre,  do_nop,  do_eor,  do_lsr,  do_sre,
     do_cli,  do_eor,  do_nop,  do_sre,  do_nop,  do_eor,  do_lsr,  do_sre,
     do_rts,  do_adc,  do_jam,  do_rra,  do_nop,  do_adc,  do_ror,  do_rra,
     do_pla,  do_adc, do_rora,  do_arr,  do_jmp,  do_adc,  do_ror,  do_rra,
     do_bvs,  do_adc,  do_jam,  do_rra,  do_nop,  do_adc,  do_ror,  do_rra,
     do_sei,  do_adc,  do_nop,  do_rra,  do_nop,  do_adc,  do_ror,  do_rra,
     do_nop,  do_sta,  do_nop,  do_sax,  do_sty,  do_sta,  do_stx,  do_sax,
     do_dey,  do_nop,  do_txa,  do_ane,  do_sty,  do_sta,  do_stx,  do_sax,
     do_bcc,  do_sta,  do_jam,  do_sha,  do_sty,  do_sta,  do_stx,  do_sax,
     do_tya,  do_sta,  do_txs,  do_tas,  do_shy,  do_sta,  do_shx,  do_sha,
     do_ldy,  do_lda,  do_ldx,  do_lax,  do_ldy,  do_lda,  do_ldx,  do_lax,
     do_tay,  do_lda,  do_tax,  do_lxa,  do_ldy,  do_lda,  do_ldx,  do_lax,
     do_bcs,  do_lda,  do_jam,  do_lax,  do_ldy,  do_lda,  do_ldx,  do_lax,
     do_clv,  do_lda,  do_tsx,  do_las,  do_ldy,  do_lda,  do_ldx,  do_lax,
     do_cpy,  do_cmp,  do_nop,  do_dcp,  do_cpy,  do_cmp,  do_dec,  do_dcp,
     do_iny,  do_cmp,  do_dex,  do_sbx,  do_cpy,  do_cmp,  do_dec,  do_dcp,
     do_bne,  do_cmp,  do_jam,  do_dcp,  do_nop,  do_cmp,  do_dec,  do_dcp,
     do_cld,  do_cmp,  do_nop,  do_dcp,  do_nop,  do_cmp,  do_dec,  do_dcp,
     do_cpx,  do_sbc,  do_nop,  do_isc,  do_cpx,  do_sbc,  do_inc,  do_isc,
     do_inx,  do_sbc,  do_nop,  do_sbc,  do_cpx,  do_sbc,  do_inc,  do_isc,
     do_beq,  do_sbc,  do_jam,  do_isc,  do_nop,  do_sbc,  do_inc,  do_isc,
     do_sed,  do_sbc,  do_nop,  do_isc,  do_nop,  do_sbc,  do_inc,  do_isc
};

static const op_t tab_amode[] = {
     op_imp,  op_izx,  op_imp,  op_izx,   op_zp,   op_zp,   op_zp,   op_zp,
     op_imp,  op_imm,  op_imp,  op_imm,  op_abs,  op_abs,  op_abs,  op_abs,
     op_rel,  op_izy,  op_imp,  op_izy,  op_zpx,  op_zpx,  op_zpx,  op_zpx,
     op_imp,  op_aby,  op_imp,  op_aby,  op_abx,  op_abx,  op_abx,  op_abx,
     op_abs,  op_izx,  op_imp,  op_izx,   op_zp,   op_zp,   op_zp,   op_zp,
     op_imp,  op_imm,  op_imp,  op_imm,  op_abs,  op_abs,  op_abs,  op_abs,
     op_rel,  op_izy,  op_imp,  op_izy,  op_zpx,  op_zpx,  op_zpx,  op_zpx,
     op_imp,  op_aby,  op_imp,  op_aby,  op_abx,  op_abx,  op_abx,  op_abx,
     op_imp,  op_izx,  op_imp,  op_izx,   op_zp,   op_zp,   op_zp,   op_zp,
     op_imp,  op_imm,  op_imp,  op_imm,  op_abs,  op_abs,  op_abs,  op_abs,
     op_rel,  op_izy,  op_imp,  op_izy,  op_zpx,  op_zpx,  op_zpx,  op_zpx,
     op_imp,  op_aby,  op_imp,  op_aby,  op_abx,  op_abx,  op_abx,  op_abx,
     op_imp,  op_izx,  op_imp,  op_izx,   op_zp,   op_zp,   op_zp,   op_zp,
     op_imp,  op_imm,  op_imp,  op_imm,  op_ind,  op_abs,  op_abs,  op_abs,
     op_rel,  op_izy,  op_imp,  op_izy,  op_zpx,  op_zpx,  op_zpx,  op_zpx,
     op_imp,  op_aby,  op_imp,  op_aby,  op_abx,  op_abx,  op_abx,  op_abx,
     op_imm,  op_izx,  op_imm,  op_izx,   op_zp,   op_zp,   op_zp,   op_zp,
     op_imp,  op_imm,  op_imp,  op_imm,  op_abs,  op_abs,  op_abs,  op_abs,
     op_rel,  op_izy,  op_imp, op_izys,  op_zpx,  op_zpx,  op_zpy,  op_zpy,
     op_imp,  op_aby,  op_imp, op_abys, op_abxs,  op_abx, op_abys, op_abys,
     op_imm,  op_izx,  op_imm,  op_izx,   op_zp,   op_zp,   op_zp,   op_zp,
     op_imp,  op_imm,  op_imp,  op_imm,  op_abs,  op_abs,  op_abs,  op_abs,
     op_rel,  op_izy,  op_imp,  op_izy,  op_zpx,  op_zpx,  op_zpy,  op_zpy,
     op_imp,  op_aby,  op_imp,  op_aby,  op_abx,  op_abx,  op_aby,  op_aby,
     op_imm,  op_izx,  op_imm,  op_izx,   op_zp,   op_zp,   op_zp,   op_zp,
     op_imp,  op_imm,  op_imp,  op_imm,  op_abs,  op_abs,  op_abs,  op_abs,
     op_rel,  op_izy,  op_imp,  op_izy,  op_zpx,  op_zpx,  op_zpx,  op_zpx,
     op_imp,  op_aby,  op_imp,  op_aby,  op_abx,  op_abx,  op_abx,  op_abx,
     op_imm,  op_izx,  op_imm,  op_izx,   op_zp,   op_zp,   op_zp,   op_zp,
     op_imp,  op_imm,  op_imp,  op_imm,  op_abs,  op_abs,  op_abs,  op_abs,
     op_rel,  op_izy,  op_imp,  op_izy,  op_zpx,  op_zpx,  op_zpx,  op_zpx,
     op_imp,  op_aby,  op_imp,  op_aby,  op_abx,  op_abx,  op_abx,  op_abx
};

static const int tab_time[] = {
         7,      6,      0,      8,      3,      3,      5,      5,
         3,      2,      2,      2,      4,      4,      6,      6,
         2,      5,      0,      8,      4,      4,      6,      6,
         2,      4,      2,      7,      4,      4,      7,      7,
         6,      6,      0,      8,      3,      3,      5,      5,
         4,      2,      2,      2,      4,      4,      6,      6,
         2,      5,      0,      8,      4,      4,      6,      6,
         2,      4,      2,      7,      4,      4,      7,      7,
         6,      6,      0,      8,      3,      3,      5,      5,
         3,      2,      2,      2,      3,      4,      6,      6,
         2,      5,      0,      8,      4,      4,      6,      6,
         2,      4,      2,      7,      4,      4,      7,      7,
         6,      6,      0,      8,      3,      3,      5,      5,
         4,      2,      2,      2,      5,      4,      6,      6,
         2,      5,      0,      8,      4,      4,      6,      6,
         2,      4,      2,      7,      4,      4,      7,      7,
         2,      6,      2,      6,      3,      3,      3,      3,
         2,      2,      2,      2,      4,      4,      4,      4,
         2,      6,      0,      6,      4,      4,      4,      4,
         2,      5,      2,      5,      5,      5,      5,      5,
         2,      6,      2,      6,      3,      3,      3,      3,
         2,      2,      2,      2,      4,      4,      4,      4,
         2,      5,      0,      5,      4,      4,      4,      4,
         2,      4,      2,      4,      4,      4,      4,      4,
         2,      6,      2,      8,      3,      3,      5,      5,
         2,      2,      2,      2,      4,      4,      6,      6,
         2,      5,      0,      8,      4,      4,      6,      6,
         2,      4,      2,      7,      4,      4,      7,      7,
         2,      6,      2,      8,      3,      3,      5,      5,
         2,      2,      2,      2,      4,      4,      6,      6,
         2,      5,      0,      8,      4,      4,      6,      6,
         2,      4,      2,      7,      4,      4,      7,      7,
};


void nu6502_reset(nu6502_state_t *cs)
{
    cs->cycles = 0;
    cs->instrs = 0;
    cs->pc = (uint16_t)READ6502(cs, 0xfffc) | ((uint16_t)READ6502(cs, 0xfffd) << 8);
    cs->acc = 0;
    cs->x = 0;
    cs->y = 0;
    cs->sp = 0xfd;
    cs->sr = FLAG_CONSTANT | FLAG_I;
}

void nu6502_step(nu6502_state_t *cs)
{
    uint8_t ir = READ6502(cs, cs->pc);
    cs->pc++;

    (tab_amode[ir])(cs);
    (tab_mne[ir])(cs);
    cs->cycles += tab_time[ir] + cs->penalty;
    cs->instrs++;

}


/* accessors */
size_t nu6502_get_ticks(nu6502_state_t *cs)
{
    return cs->cycles;
}

size_t nu6502_get_count(nu6502_state_t *cs)
{
    return cs->instrs;
}

uint16_t nu6502_get_pc(nu6502_state_t *cs)
{
    return cs->pc;
}

void nu6502_set_pc(nu6502_state_t *cs, uint16_t val)
{
    cs->pc = val;
}

uint8_t nu6502_get_sp(nu6502_state_t *cs)
{
    return cs->sp;
}

void nu6502_set_sp(nu6502_state_t *cs, uint8_t val)
{
    cs->sp = val;
}

uint8_t nu6502_get_acc(nu6502_state_t *cs)
{
    return cs->acc;
}

void nu6502_set_acc(nu6502_state_t *cs, uint8_t val)
{
    cs->acc = val;
}

uint8_t nu6502_get_x(nu6502_state_t *cs)
{
    return cs->x;
}

void nu6502_set_x(nu6502_state_t *cs, uint8_t val)
{
    cs->x = val;
}

uint8_t nu6502_get_y(nu6502_state_t *cs)
{
    return cs->y;
}

void nu6502_set_y(nu6502_state_t *cs, uint8_t val)
{
    cs->y = val;
}

uint8_t nu6502_get_sr(nu6502_state_t *cs)
{
    return cs->sr;
}

void nu6502_set_sr(nu6502_state_t *cs, uint8_t val)
{
    cs->sr = val;
}



#if 1
/*******
 *
 * Legacy interface
 *
 */
void reset6502(void)
{
    nu6502_reset(cs);
}

void step6502(void)
{
    nu6502_step(cs);
}


/* accessors */
uint32_t get6502ticks(void)
{
    return nu6502_get_ticks(cs);
}

uint32_t get6502count(void)
{
    return nu6502_get_count(cs);
}

uint16_t get6502pc(void)
{
    return nu6502_get_pc(cs);
}

void set6502pc(uint16_t val)
{
    nu6502_set_pc(cs, val);
}

uint8_t get6502sp(void)
{
    return nu6502_get_sp(cs);
}

void set6502sp(uint8_t val)
{
    nu6502_set_sp(cs, val);
}

uint8_t get6502acc(void)
{
    return nu6502_get_acc(cs);
}

void set6502acc(uint8_t val)
{
    nu6502_set_acc(cs, val);
}

uint8_t get6502x(void)
{
    return nu6502_get_x(cs);
}

void set6502x(uint8_t val)
{
    nu6502_set_x(cs, val);
}

uint8_t get6502y(void)
{
    return nu6502_get_y(cs);
}

void set6502y(uint8_t val)
{
    nu6502_set_y(cs, val);
}

uint8_t get6502sr(void)
{
    return nu6502_get_sr(cs);
}

void set6502sr(uint8_t val)
{
    nu6502_set_sr(cs, val);
}
#endif

/* eof */
