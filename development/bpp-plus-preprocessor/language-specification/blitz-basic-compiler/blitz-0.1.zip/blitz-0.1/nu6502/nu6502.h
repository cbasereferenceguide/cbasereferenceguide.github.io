/**************************************************************************
 *
 * FILE  nu6502.h
 * Copyright (c) 2018 Daniel Kahlin <daniel@kahlin.net>
 * Written by Daniel Kahlin <daniel@kahlin.net>
 *
 * DESCRIPTION
 *   6502 emulator
 *
 ******/
#ifndef NU6502_H
#define NU6502_H

#include <stdint.h>
#include <stdlib.h>

/* predeclaration */
struct s_nu6502_state_t;
typedef struct s_nu6502_state_t nu6502_state_t;

typedef enum { NU6502_DEFAULT } nu6502_access_mode_t;

typedef uint8_t (nu6502_read_func_t)(nu6502_state_t *user, uint16_t addr, nu6502_access_mode_t am);
typedef void (nu6502_write_func_t)(void *user, uint16_t addr, uint8_t val, nu6502_access_mode_t am);

/******
 * CPU emulation state
 * NOTE: use accessors to manipulate this!
 */
struct s_nu6502_state_t {
    /* registers */
    uint8_t acc;
    uint8_t y;
    uint8_t x;
    uint8_t sr;
    uint8_t sp;
    uint16_t pc;

    /* statistics */
    size_t cycles;
    size_t instrs;

    /* temp */
    uint16_t ea;
    size_t penalty;
};


void nu6502_init(nu6502_state_t *cs, void *user, nu6502_read_func_t *rd, nu6502_write_func_t *wr);

void nu6502_reset(nu6502_state_t *cs);
#if 0
/* interrupts not supported for now */
void nu6502_nmi(nu6502_state_t *cs);
void nu6502_irq(nu6502_state_t *cs);
#endif
void nu6502_step(nu6502_state_t *cs);

/* accessor wrappers */
size_t nu6502_get_ticks(nu6502_state_t *cs);
size_t nu6502_get_count(nu6502_state_t *cs);

uint16_t nu6502_get_pc(nu6502_state_t *cs);
void nu6502_set_pc(nu6502_state_t *cs, uint16_t val);

uint8_t nu6502_get_sp(nu6502_state_t *cs);
void nu6502_set_sp(nu6502_state_t *cs, uint8_t val);

uint8_t nu6502_get_acc(nu6502_state_t *cs);
void nu6502_set_acc(nu6502_state_t *cs, uint8_t val);

uint8_t nu6502_get_x(nu6502_state_t *cs);
void nu6502_set_x(nu6502_state_t *cs, uint8_t val);

uint8_t nu6502_get_y(nu6502_state_t *cs);
void nu6502_set_y(nu6502_state_t *cs, uint8_t val);

uint8_t nu6502_get_sr(nu6502_state_t *cs);
void nu6502_set_sr(nu6502_state_t *cs, uint8_t val);


#if 1
/*******
 *
 * Legacy interface
 *
 */

/* externally supplied memory access functions */
extern uint8_t read6502(uint16_t address);
extern void write6502(uint16_t address, uint8_t value);

void reset6502(void);
void step6502(void);

/* accessor wrappers */
uint32_t get6502ticks(void);
uint32_t get6502count(void);

uint16_t get6502pc(void);
void set6502pc(uint16_t val);

uint8_t get6502sp(void);
void set6502sp(uint8_t val);

uint8_t get6502acc(void);
void set6502acc(uint8_t val);

uint8_t get6502x(void);
void set6502x(uint8_t val);

uint8_t get6502y(void);
void set6502y(uint8_t val);

uint8_t get6502sr(void);
void set6502sr(uint8_t val);
#endif


#endif /* NU6502_H */
/* eof */
