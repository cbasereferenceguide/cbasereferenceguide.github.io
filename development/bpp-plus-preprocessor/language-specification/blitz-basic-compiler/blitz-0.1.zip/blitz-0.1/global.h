/**************************************************************************
 *
 * FILE  global.h
 * Copyright (c) 2017, 2018 Daniel Kahlin
 * Written by Daniel Kahlin <daniel@kahlin.net>
 *
 * DESCRIPTION
 *   Global variables and functions
 *
 ******/
#ifndef GLOBAL_H
#define GLOBAL_H
#include <stdarg.h>

#define PACKAGE "crunchlab"

extern const char program_g[];
extern int verbose_g;
extern int debug_g;

void panic(const char *str, ...);

#endif /* GLOBAL_H */
/* eof */
