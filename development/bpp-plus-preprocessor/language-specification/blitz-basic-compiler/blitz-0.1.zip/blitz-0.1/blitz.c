/**************************************************************************
 *
 * FILE  blitz.c
 * Copyright (c) 2018 Daniel Kahlin <daniel@kahlin.net>
 * Written by Daniel Kahlin <daniel@kahlin.net>
 *
 * DESCRIPTION
 *   Wrapper for the Blitz!/Austro-Comp compiler
 *
 ******/
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "buffer.h"
#include "blitz_bin.h"
#include "embed_load.h"
#include "global.h"
#include "helpers.h"
#include "iosys.h"
#include "slre/slre.h"
#include "system.h"
#include "utils.h"


#define PROGRAM "blitz"
#define VERSION "0.1"

const char program_g[] = PROGRAM;

#define TICK_LIMIT (10000000000)

static void blitz_write_interpreter(const char *destname);
static void blitz_compile(const char *srcname, const char *destname, int pcode_only);

static void austro_write_interpreter(const char *destname);
static void austro_compile(const char *srcname, const char *destname, int pcode_only);


int main(int argc, char *argv[])
{
    int c;
    char *srcname = 0;
    char *destname = "a.prg";
    enum { MODE_FULL, MODE_PCODE_ONLY, MODE_INTERPRETER_ONLY } mode;
    enum { COMP_BLITZ, COMP_AUSTROCOMP } compiler;

    /* defaults */
    verbose_g = 0;
    debug_g = 0;
    mode = MODE_FULL;
    compiler = COMP_BLITZ;

    /*
     * scan for valid options
     */
    while (EOF != (c = getopt(argc, argv, "c:pio:qvdVhH"))) {
        switch (c) {

	/* a missing parameter */
	case ':':
	/* an illegal option */
	case '?':
	    exit(1);

	/* set quiet mode */
	case 'q':
	    verbose_g = 0;
	    break;

	/* set verbose mode */
	case 'v':
	    verbose_g++;
	    break;

	/* set debug mode */
	case 'd':
	    debug_g = 1;
	    break;

	/* print version */
	case 'V':
	    fprintf (stdout, PROGRAM " " VERSION "\n");
	    exit(0);

	/* print help */
	case 'h':
	    fprintf(stderr,
PROGRAM " " VERSION ": Blitz!/Austro-Comp compiler\n"
"Written 2018 by Daniel Kahlin <daniel@kahlin.net>\n"
"\n"
"The original c64 compilers contained within is:\n"
"  Blitz! 64 by Skyles Electric Works\n"
"  Austro-Comp by Commodore Buromaschinen GmbH\n"
"\n"
"usage: " PROGRAM " [OPTION] FILE...\n"
"\n"
"Valid options:\n"
"    -c<name>        compiler: blitz/austro (default: blitz)\n"
"    -p              generate pcode only\n"
"    -i              generate interpreter only\n"
"    -o<name>        output file\n"
"    -q              be quiet\n"
"    -v              be verbose (can be multiple)\n"
"    -d              display debug information\n"
"    -h              displays this help text\n"
"    -H              display original c64 documentation by DOC'S \"R\" US BBS\n"
"    -V              output program version\n"
	    );
	    exit(0);

	/* print original docs */
	case 'H':
	    reset_embedded(&blitzdoc_emb);
	    while ( c = get_embedded(&blitzdoc_emb), c != '\r');
	    while ( c = get_embedded(&blitzdoc_emb), c != EOF) {
		putchar(convert_petscii(c));
	    }
	    exit(0);

	/* set destination name */
	case 'o':
	    destname = optarg;
	    break;

	/* set compiler type */
	case 'c':
	    if (!strcmp(optarg, "blitz")) {
		compiler = COMP_BLITZ;
		break;
	    }
	    if (!strcmp(optarg, "austro")) {
		compiler = COMP_AUSTROCOMP;
		break;
	    }
	    panic("invalid compiler '%s'", optarg);
	    break;

	/* set pcode only mode */
	case 'p':
	    mode = MODE_PCODE_ONLY;
	    break;

	/* set interpreter only mode */
	case 'i':
	    mode = MODE_INTERPRETER_ONLY;
	    break;

	/* default behavior */
	default:
	    break;
	}
    }

    /*
     * optind now points at the first non option argument
     */
    int num_files = argc - optind;
    if (mode == MODE_INTERPRETER_ONLY) {
	if (num_files > 0) {
	    panic("too many arguments");
	}
    } else {
	if (num_files < 1) {
	    panic("too few arguments");
	}
	if (num_files > 1) {
	    panic("too many arguments");
	}
	srcname = argv[optind];
    }


    if (compiler == COMP_BLITZ) {
	switch (mode) {
	case MODE_FULL:
	    blitz_compile(srcname, destname, 0);
	    break;
	case MODE_INTERPRETER_ONLY:
	    blitz_write_interpreter(destname);
	    break;
	case MODE_PCODE_ONLY:
	    blitz_compile(srcname, destname, 1);
	    break;
	default:
	    panic("internal: invalid mode");
	}
    }
    if (compiler == COMP_AUSTROCOMP) {
	switch (mode) {
	case MODE_FULL:
	    austro_compile(srcname, destname, 0);
	    break;
	case MODE_INTERPRETER_ONLY:
	    austro_write_interpreter(destname);
	    break;
	case MODE_PCODE_ONLY:
	    austro_compile(srcname, destname, 1);
	    break;
	default:
	    panic("internal: invalid mode");
	}
    }

    exit(0);
}




Buffer *in_bf;
Buffer *out_bf;
Buffer *pcode_bf;
Buffer *data_bf;
Buffer *xref_bf;

static void run_until_rts(uint16_t addr)
{
    uint8_t sp = get6502sp();
    set6502pc(addr);

    while (1) {
	uint16_t pc;

	pc = get6502pc();
	if (read6502(pc) == 0x60 && get6502sp() == sp) {
	    //printf("%04x\n", pc);
	    break;
	}
	step6502();
    }
}

static void run_bp(uint16_t addr)
{
    while (get6502ticks() < TICK_LIMIT) {
	uint16_t pc;

	//printf("%04X\n", get6502pc());
	step6502();
	pc = get6502pc();
	if (pc == addr) {
	    break;
	}
	switch (pc) {
	case 0xffd2:
	    kernal_chrout();
	    break;
	case 0xffcf:
	    kernal_chrin();
	    break;
	case 0xffc0:
	    kernal_open();
	    break;
	case 0xffc6:
	    kernal_chkin();
	    break;
	case 0xffcc:
	    kernal_clrchn();
	    break;
	case 0xffc3:
	    kernal_close();
	    break;
	case 0xffc9:
	    kernal_chkout();
	    break;
	case 0xffe7:
	    kernal_clall();
	    break;
	case 0xffe4:
	    kernal_chrin();
	    break;
	case 0xfff0:
	    kernal_plot();
	    break;
	case 0x0000:
	    printf("out!\n");
	    exit(1);
	    break;
	default:
	    break;
	}

    }

}

static void run_until_bp(uint16_t addr, uint16_t bp)
{
    set6502pc(addr);
    run_bp(bp);
}


void save_ram(const char *name, uint16_t sa, uint16_t ea, int la)
{
    FILE *fp;
    int i;
    int l = ea - sa;

    if (ea == 0x0000) {
	l = 0x10000 - sa;
    }

    if (la < 0) {
	la = sa;
    }

    fp = fopen(name, "wb");
    fputc(la & 0xff, fp);
    fputc(la >> 8, fp);
    for (i = 0; i < l; i++) {
	fputc(read6502(sa + i), fp);
    }
    fclose(fp);
}


/**************************************************************************
 *
 * SECTION  Skyles Blitz
 *
 * DESCRIPTION
 *   Wrapper for the Blitz! compiler
 *
 ******/
static int blitz_in_hook(char *str, void *user)
{
    static enum {
	STATE_MENU,
	STATE_FILENAME,
	STATE_WAIT_COMPILE,
	STATE_COMPILE,
	STATE_FINISH
    } state = STATE_MENU;

    switch (state) {
    case STATE_MENU:
	/* skyles - blitz */
	if (!slre_match(0, "floppies with different", str, strlen(str))) {
	    set_linein("1");

	    state = STATE_FILENAME;
	    return 0;
	}
	break;
    case STATE_FILENAME:
	if (!strcmp(str, "filename    :? ")) {
	    set_linein("y\r");
	    state = STATE_WAIT_COMPILE;
	    return 1;
	}
	break;
    case STATE_WAIT_COMPILE:
	if (!slre_match(0, "^pass", str, strlen(str))) {
	    set_print_mode(1);
	    state = STATE_COMPILE;
	    return 0;
	}
	break;
    case STATE_COMPILE:
	if (!slre_match(0, "^errors.+extensions", str, strlen(str))) {
	    printf("\n");
	    state = STATE_FINISH;
	    return 0;
	}
	if (!slre_match(0, "^pass", str, strlen(str))) {
	    printf("\n");
	    return 0;
	}
	if (!slre_match(0, "\\?extentions", str, strlen(str))) {
	    return 1;
	}
	if (!slre_match(0, "^\\s*$", str, strlen(str))) {
	    return 1;
	}
	if (!slre_match(0, "^\\s*\\d+\\s*$", str, strlen(str))) {
	    str[strlen(str)-1] = '\r';
	    return 0;
	}
	break;
    case STATE_FINISH:
	if (!slre_match(0, "^\\s*$", str, strlen(str))) {
	    return 1;
	}
	if (!slre_match(0, "^\\s*\\d+ \\S+", str, strlen(str))) {
	    /* 0 ok */
	    return 1;
	}
	break;
    default:
	panic("internal: invalid state during compilation");
    }

    return 0;
}


#define BLITZ_INTERPRETER_SA 0x0801
#define BLITZ_INTERPRETER_EA 0x1f93

static void blitz_write_interpreter(const char *destname)
{
    load_ram_emb(&blitz_emb, -1, 0, 0, 0);
    save_ram(destname, BLITZ_INTERPRETER_SA, BLITZ_INTERPRETER_EA, -1);
}


static void blitz_compile(const char *srcname, const char *destname, int pcode_only)
{

    in_bf = create_buffer_from_file(srcname);

    out_bf = create_buffer(0x10000);
    pcode_bf = create_buffer(0x10000);
    data_bf = create_buffer(0x10000);
    xref_bf = create_buffer(0x10000);

    add_file(8, 0, "y", 'p', MODE_RO, in_bf);
    add_file(8, 0, "c/y", 'p', MODE_RW, out_bf);
    add_file(8, 0, "p/y", 's', MODE_RW, pcode_bf);
    add_file(8, 0, "d/y", 's', MODE_RW, data_bf);
    add_file(8, 0, "z/y", 'p', MODE_WO, xref_bf);

    /******
     *
     *
     */
    init_system();
    reset6502();

    /* initial run */
    set6502sp(0xf6);

    run_until_rts(0xfd50);
    run_until_rts(0xfd15);
    run_until_rts(0xe453);
    run_until_rts(0xe3bf);
    run_until_bp(0xa644, 0xa68d);

    uint16_t ea;
    load_ram_emb(&blitz_emb, -1, 0, &ea, 0);

    write6502(0x02d, ea & 0xff);
    write6502(0x02e, ea >> 8);

    /* initial run */
    set6502sp(0xf6);
    run_until_bp(0xa52a, 0xa480);


    set_in_hook(blitz_in_hook, 0);
    set_print_mode(0);

    //printf("-----------------------------------------\n");
    run_until_bp(0x081c, 0xa474);
    //printf("-----------------------------------------\n");

    /* free input buffer */
    destroy_buffer(in_bf);

    if (debug_g) {
	/* write out temporaries */
	write_buffer_to_file(pcode_bf, "a_pcode.prg");
	write_buffer_to_file(data_bf, "a_data.prg");
    }

    /* free temporary buffer */
    destroy_buffer(pcode_bf);
    destroy_buffer(data_bf);

    /* write out binaries */
    if (!pcode_only) {
	write_buffer_to_file(out_bf, destname);
    } else {
	uint16_t sa, ea;
	load_buffer(out_bf, -1, &sa, &ea, 0);
	save_ram(destname, BLITZ_INTERPRETER_EA, ea, -1);
    }
    if (xref_bf->len > 0) {
	char name[256];
	strncpy(name, destname, sizeof(name));
	strncat(name, ".xref", sizeof(name));
	write_buffer_to_file(xref_bf, name);
    }

    /* free output buffers */
    destroy_buffer(out_bf);
    destroy_buffer(xref_bf);

    exit(0);
}


/**************************************************************************
 *
 * SECTION  Austro Comp
 *
 * DESCRIPTION
 *   Wrapper for the Austro-Comp compiler
 *
 ******/
static int austro_in_hook(char *str, void *user)
{
    static enum {
	STATE_FILENAME,
	STATE_WAIT_COMPILE,
	STATE_COMPILE,
	STATE_FINISH
    } state = STATE_FILENAME;

    switch (state) {
    case STATE_FILENAME:
	if (!strcmp(str, "Programmname:? ")) {
	    set_linein("y\r");
	    state = STATE_WAIT_COMPILE;
	    return 1;
	}
	break;
    case STATE_WAIT_COMPILE:
	if (!slre_match(0, "^pass", str, strlen(str))) {
	    set_print_mode(1);
	    state = STATE_COMPILE;
	    return 0;
	}
	break;
    case STATE_COMPILE:
	if (!slre_match(0, "^errors.+exten.ions", str, strlen(str))) {
	    printf("\n");
	    state = STATE_FINISH;
	    return 0;
	}
	if (!slre_match(0, "^pass", str, strlen(str))) {
	    printf("\n");
	    return 0;
	}
	if (!slre_match(0, "\\?extentions", str, strlen(str))) {
	    return 1;
	}
	if (!slre_match(0, "^\\s*$", str, strlen(str))) {
	    return 1;
	}
	if (!slre_match(0, "^\\s*\\d+\\s*$", str, strlen(str))) {
	    str[strlen(str)-1] = '\r';
	    return 0;
	}
	break;
    case STATE_FINISH:
	if (!slre_match(0, "^\\s*$", str, strlen(str))) {
	    return 1;
	}
	if (!slre_match(0, "^\\s*\\d+ \\S+", str, strlen(str))) {
	    /* 0 ok */
	    return 1;
	}
	break;
    default:
	panic("internal: invalid state during compilation");
    }

    return 0;
}

#define AUSTRO_INTERPRETER_SA 0x0801
#define AUSTRO_INTERPRETER_EA 0x1792

static void austro_write_interpreter(const char *destname)
{
    load_ram_emb(&austro_emb, -1, 0, 0, 0);
    save_ram(destname, AUSTRO_INTERPRETER_SA, AUSTRO_INTERPRETER_EA, -1);
}


static void austro_compile(const char *srcname, const char *destname, int pcode_only)
{

    in_bf = create_buffer_from_file(srcname);

    out_bf = create_buffer(0x10000);
    pcode_bf = create_buffer(0x10000);
    data_bf = create_buffer(0x10000);
    xref_bf = create_buffer(0x10000);

    add_file(8, 0, "y", 'p', MODE_RO, in_bf);
    add_file(8, 0, "c/y", 'p', MODE_RW, out_bf);
    add_file(8, 0, "p/y", 's', MODE_RW, pcode_bf);
    add_file(8, 0, "d/y", 's', MODE_RW, data_bf);
    add_file(8, 0, "z/y", 'p', MODE_WO, xref_bf);

    /******
     *
     *
     */
    init_system();
    reset6502();

    /* initial run */
    set6502sp(0xf6);

    run_until_rts(0xfd50);
    run_until_rts(0xfd15);
    run_until_rts(0xe453);
    run_until_rts(0xe3bf);
    run_until_bp(0xa644, 0xa68d);

    uint16_t ea;
    load_ram_emb(&austro_emb, -1, 0, &ea, 0);

    write6502(0x02d, ea & 0xff);
    write6502(0x02e, ea >> 8);

    /* initial run */
    set6502sp(0xf6);
    run_until_bp(0xa52a, 0xa480);


    set_in_hook(austro_in_hook, 0);
    set_print_mode(0);

    //printf("-----------------------------------------\n");
    run_until_bp(0x081c, 0xa474);
    //printf("-----------------------------------------\n");

    /* free input buffer */
    destroy_buffer(in_bf);

    if (debug_g) {
	/* write out temporaries */
	write_buffer_to_file(pcode_bf, "a_pcode.prg");
	write_buffer_to_file(data_bf, "a_data.prg");
    }

    /* free temporary buffer */
    destroy_buffer(pcode_bf);
    destroy_buffer(data_bf);

    /* write out binaries */
    if (!pcode_only) {
	write_buffer_to_file(out_bf, destname);
    } else {
	uint16_t sa, ea;
	load_buffer(out_bf, -1, &sa, &ea, 0);
	save_ram(destname, AUSTRO_INTERPRETER_EA, ea, -1);
    }
    if (xref_bf->len > 0) {
	char name[256];
	strncpy(name, destname, sizeof(name));
	strncat(name, ".xref", sizeof(name));
	write_buffer_to_file(xref_bf, name);
    }

    /* free output buffers */
    destroy_buffer(out_bf);
    destroy_buffer(xref_bf);

    exit(0);
}


/* eof */
