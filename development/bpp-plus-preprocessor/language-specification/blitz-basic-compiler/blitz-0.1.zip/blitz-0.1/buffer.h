/**************************************************************************
 *
 * FILE  buffer.h
 * Copyright (c) 2017 Daniel Kahlin <daniel@kahlin.net>
 * Written by Daniel Kahlin <daniel@kahlin.net>
 *
 * DESCRIPTION
 *   handling of buffers
 *
 ******/
#ifndef BUFFER_H
#define BUFFER_H

#include <stdint.h>
#include <stdlib.h>

typedef struct {
    uint8_t *buf;
    size_t size;

    size_t pos;
    size_t len;

} Buffer;


Buffer *create_buffer(size_t size);
void destroy_buffer(Buffer *bf);
Buffer *create_buffer_from_file(const char *name);
void write_buffer_to_file(Buffer *bf, const char *name);


/* this below should probably go to a separate file */
typedef struct {
    Buffer *bf;
    int jmp;
    int mem;
    int sei;
} PrgObj;

PrgObj *create_prgobj(size_t size);
PrgObj *create_prgobj_from_file(const char *name);
void write_prgobj_to_file(PrgObj *po, const char *name);
void destroy_prgobj(PrgObj *po);

#endif /* BUFFER_H */
/* eof */
