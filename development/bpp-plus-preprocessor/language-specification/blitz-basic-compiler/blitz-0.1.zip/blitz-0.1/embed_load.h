/**************************************************************************
 *
 * FILE  embed_load.h
 * Copyright (c) 2018 Daniel Kahlin <daniel@kahlin.net>
 * Written by Daniel Kahlin <daniel@kahlin.net>
 *
 * DESCRIPTION
 *   Loader for embedded files.
 *
 ******/
#ifndef EMBED_LOAD_H
#define EMBED_LOAD_H

#include <stdint.h>
#include <stdlib.h>

typedef struct {
    const uint8_t *data;
    const size_t len;
    size_t pos;
} Embedded;


void reset_embedded(Embedded *emb);
int get_embedded(Embedded *emb);
size_t load_embedded(Embedded *emb, uint8_t *dest);

#endif /* EMBED_LOAD_H */
/* eof */
