/* mlsplit -- split ml0123 into ml0, ml1, ml2, and ml3
 *
 * Copyright © 2003-2007 David Weinehall
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software Foundation,
 *  Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */
#include <errno.h>
#include <stdio.h>
#include <stdint.h>
#include <string.h>

const char *filename = "ml0123";
const char *ml0name = "ml0";
const char *ml1name = "ml1";
const char *ml2name = "ml2";
const char *ml3name = "ml3";

uint16_t tmpbuf[8];

static int write_file(const uint16_t size, const uint16_t start,
		      const char *ofile, FILE *fp)
{
	FILE *ofp = NULL;
	int status = 0;
	int tmp = 0;
	int i = 0;

	if (!(ofp = fopen(ofile, "w"))) {
		fprintf(stderr,
			"Failed to open %s for writing; %s. Aborting.\n",
			ofile, strerror(errno));
		status = errno;
		goto EXIT;
	}

	if (fputc(start & 0xff, ofp) == EOF) {
		fprintf(stderr,
			"Failed to write %s; %s. Aborting.\n",
			ofile, strerror(errno));
		status = errno;
		goto EXIT;
	}

	if (fputc(start >> 8, ofp) == EOF) {
		fprintf(stderr,
			"Failed to write %s; %s. Aborting.\n",
			ofile, strerror(errno));
		status = errno;
		goto EXIT;
	}

	while (i++ < size) {
		if ((tmp = fgetc(fp)) == EOF) {
			if (feof(fp)) {
				fprintf(stderr,
					"Failed to read %s; "
					"unexpected end of file. "
					"Aborting.\n",
					filename);
				status = EINVAL;
				goto EXIT;
			} else {
				fprintf(stderr,
					"Failed to read %s; %s. Aborting.\n",
					filename, strerror(errno));
				status = errno;
				goto EXIT;
			}
		}

		if (fputc(tmp, ofp) == EOF) {
			fprintf(stderr,
				"Failed to write %s; %s. Aborting.\n",
				ofile, strerror(errno));
			status = errno;
			goto EXIT;
		}
	}

	if (fclose(ofp) == EOF) {
		fprintf(stderr,
			"Failed to close %s; %s. Aborting.\n",
			ofile, strerror(errno));
		status = errno;
		goto EXIT;
	}

EXIT:
	return status;
}

int main(void)
{
	int status = 0;
	FILE *fp = NULL;

	if (!(fp = fopen(filename, "r"))) {
		fprintf(stderr,
			"Failed to open %s; %s. Aborting.\n",
			filename, strerror(errno));
		status = errno;
		goto EXIT;
	}

	if (fread(&tmpbuf, 2, 8, fp) != 8) {
		if (feof(fp)) {
			fprintf(stderr,
				"Failed to read %s; "
				"unexpected end of file. "
				"Aborting.\n",
				filename);
			status = EINVAL;
			goto EXIT;
		} else {
			fprintf(stderr,
				"Failed to read %s; %s. Aborting.\n",
				filename, strerror(errno));
			status = errno;
			goto EXIT;
		}
	}

	if (write_file(tmpbuf[0], tmpbuf[1], ml0name, fp))
		goto EXIT;

	if (write_file(tmpbuf[2], tmpbuf[3], ml1name, fp))
		goto EXIT;

	if (write_file(tmpbuf[4], tmpbuf[5], ml2name, fp))
		goto EXIT;

	if (write_file(tmpbuf[6], tmpbuf[7], ml3name, fp))
		goto EXIT;

	if (fclose(fp) == EOF) {
		fprintf(stderr,
			"Failed to close %s; %s. Aborting.\n",
			filename, strerror(errno));
		status = errno;
		goto EXIT;
	}

EXIT:
	return status;
}
