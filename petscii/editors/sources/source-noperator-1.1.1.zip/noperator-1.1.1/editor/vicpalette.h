#pragma once

#include <QRgb>

static const QRgb vicPalette[16] = {  // Pepto
   0x000000u,
   0xffffffu,
   0x68372Bu,
   0x70A4B2u,
   0x6F3D86u,
   0x588D43u,
   0x352879u,
   0xB8C76Fu,
   0x6F4F25u,
   0x433900u,
   0x9A6759u,
   0x444444u,
   0x6C6C6Cu,
   0x9AD284u,
   0x6C5EB5u,
   0x959595u
};
