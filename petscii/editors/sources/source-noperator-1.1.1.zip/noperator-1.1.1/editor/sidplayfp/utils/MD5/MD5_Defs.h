#ifndef MD5_DEFS_H
#define MD5_DEFS_H

#include "sidplayfp/sidendian.h"

#ifdef WORDS_BIGENDIAN
#  define MD5_WORDS_BIG_ENDIAN
#endif

#endif /* MD5_DEFS_H */
