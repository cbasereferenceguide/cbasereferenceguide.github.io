# noperator
C64 movie maker similar to Letter Noperator

[![hits with tits](http://img.youtube.com/vi/iJZS8hvDWXc/0.jpg)](http://www.youtube.com/watch?v=iJZS8hvDWXc)
